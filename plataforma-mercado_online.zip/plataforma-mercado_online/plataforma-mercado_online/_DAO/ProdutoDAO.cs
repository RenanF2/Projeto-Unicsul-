﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class ProdutoDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        
        //Método construdor, instanciando classe ProdutoDAO e realizando conexão
        public ProdutoDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Métodos com uso de comandos sql e do objeto Produto
        public string gravarProduto(Produto produto)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Produto (id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, quant_produto, quant_min_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec) ";
                sql += "VALUES (" + produto.IdProduto + ", " +  produto.CodBarras + ", '" + produto.NomeProduto + "', '" + produto.DescricaoProduto + "', " + produto.PrecoUnitario + ", " + produto.QuantEstoque + ", " + produto.QuantMinimaEstoque +", " + produto.Categoria.IdCategoria + ", " + produto.Fornecedor.IdFornecedor + ")";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }

            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarProduto(Produto produto)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Produto SET cod_barras_produto = " + produto.CodBarras + ", nome_produto = '" + produto.NomeProduto + "', descr_produto = '" + produto.DescricaoProduto + "', precUnit_produto = " + produto.PrecoUnitario + ", ";
                sql += "quant_produto = " + produto.QuantEstoque + ", quant_min_produto = " + produto.QuantMinimaEstoque + ", fk_Fornecedor_id_fornec = " + produto.Fornecedor.IdFornecedor + ", fk_Categoria_id_categoria = " + produto.Categoria.IdCategoria + " ";
                sql += "WHERE id_produto = " + produto.IdProduto;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
                return resp;
        }

        public string excluirProduto(int id)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "DELETE FROM Produto WHERE id_produto = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Produto pesquisarProduto(int id)
        {
            Produto prod = new Produto();
            string sql;

            try
            {
                sql = "SELECT id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, quant_produto, quant_min_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec FROM Produto WHERE id_produto = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    prod.IdProduto = Int32.Parse(dr["id_produto"].ToString());
                    prod.CodBarras = Int32.Parse(dr["cod_barras_produto"].ToString());
                    prod.NomeProduto = dr["nome_produto"].ToString();
                    prod.DescricaoProduto = dr["descr_produto"].ToString();
                    prod.PrecoUnitario = Int32.Parse(dr["precUnit_produto"].ToString());
                    prod.QuantEstoque = Int32.Parse(dr["quant_produto"].ToString());
                    prod.QuantMinimaEstoque = Int32.Parse(dr["quant_min_produto"].ToString());
                    //necessidade de instanciar um objeto categoria e fornecedor para passar os IDs no objeto prod
                    prod.Categoria = new Categoria
                    {
                        IdCategoria = Int32.Parse(dr["fk_Categoria_id_categoria"].ToString())
                    };
                    prod.Fornecedor = new Fornecedor
                    {
                        IdFornecedor = Int32.Parse(dr["fk_Fornecedor_id_fornec"].ToString())
                    };

                    return prod;
                }
                else
                {
                    prod.NomeProduto = "Não existe este produto no sistema.";
                    return prod;
                }
            }
            catch (Exception erro)
            {
                prod.NomeProduto = "ERRO: " + erro.ToString();
                return prod;
            }
        }
    }
}