﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class ProdutoDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        
        //Método construdor, instanciando classe ProdutoDAO e realizando conexão
        public ProdutoDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Métodos com uso de comandos sql e do objeto Produto
        public string gravarProduto(Produto produto)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "INSERT INTO Produto (id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, quant_produto, quant_min_produto, img_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec) ";
                sql += "VALUES (" + produto.IdProduto + ", " +  produto.CodBarras + ", '" + produto.NomeProduto + "', '" + produto.DescricaoProduto + "', " + produto.PrecoUnitario + ", " + produto.QuantEstoque + ", " + produto.QuantMinimaEstoque +", '" + produto.ImgProduto + "', " + produto.Categoria.IdCategoria + ", " + produto.Fornecedor.IdFornecedor + ")";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }

            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarProduto(Produto produto)
        {
            string resp, sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Produto SET cod_barras_produto = " + produto.CodBarras + ", nome_produto = '" + produto.NomeProduto + "', descr_produto = '" + produto.DescricaoProduto + "', precUnit_produto = " + produto.PrecoUnitario + ", ";
                sql += "quant_produto = " + produto.QuantEstoque + ", quant_min_produto = " + produto.QuantMinimaEstoque + ", fk_Fornecedor_id_fornec = " + produto.Fornecedor.IdFornecedor + ", fk_Categoria_id_categoria = " + produto.Categoria.IdCategoria + " ";
                sql += "WHERE id_produto = " + produto.IdProduto;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
                return resp;
        }

        public string atualizarEstoqueProduto(Produto produto)
        {
            string resp, sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Produto SET quant_produto = " + produto.QuantEstoque + " WHERE id_produto = " + produto.IdProduto;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração do estoque - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirProduto(int id)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "DELETE FROM Produto WHERE id_produto = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Produto pesquisarProduto(int id)
        {
            Produto prod = new Produto();
            string sql;
            try
            {
                sql = "SELECT id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, format(precUnit_produto, 'C', 'pt-br') as precoFormatado, quant_produto, quant_min_produto, img_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec FROM Produto WHERE id_produto = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    prod.IdProduto = Int32.Parse(dr["id_produto"].ToString());
                    prod.CodBarras = Int32.Parse(dr["cod_barras_produto"].ToString());
                    prod.NomeProduto = dr["nome_produto"].ToString();
                    prod.DescricaoProduto = dr["descr_produto"].ToString();
                    prod.PrecoUnitario = Double.Parse(dr["precUnit_produto"].ToString());
                    prod.PrecoUnitarioConvertido = dr["precoFormatado"].ToString();
                    prod.QuantEstoque = Int32.Parse(dr["quant_produto"].ToString());
                    prod.QuantMinimaEstoque = Int32.Parse(dr["quant_min_produto"].ToString());
                    prod.ImgProduto = dr["img_produto"].ToString();
                    //necessidade de instanciar um objeto categoria e fornecedor para passar os IDs no objeto prod
                    prod.Categoria = new Categoria
                    {
                        IdCategoria = Int32.Parse(dr["fk_Categoria_id_categoria"].ToString())
                    };
                    prod.Fornecedor = new Fornecedor
                    {
                        IdFornecedor = Int32.Parse(dr["fk_Fornecedor_id_fornec"].ToString())
                    };

                    return prod;
                }
                else
                {
                    prod.NomeProduto = "Não existe este produto no sistema.";
                    return prod;
                }
            }
            catch (Exception erro)
            {
                prod.NomeProduto = "ERRO: " + erro.ToString();
                return prod;
            }
        }
    
        public List<Produto> pesquisarProdutosEspecificos(string nomeProduto, int idCategoria)
        {
            List<Produto> produtos = new List<Produto>();
            string sql;
            int metodosPesquisa = 0;
            try
            {
                sql = "SELECT id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, format(precUnit_produto, 'C', 'pt-br') as precoFormatado, quant_produto, quant_min_produto, img_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec FROM Produto ";

                if (nomeProduto != null) {
                    sql += "WHERE nome_produto LIKE '%" + nomeProduto + "%' ";
                    metodosPesquisa++;
                }
                
                if(idCategoria != 0)
                {
                    if(metodosPesquisa > 0)
                    {
                        sql += " AND ";
                    }
                    else
                    {
                        sql += " WHERE ";
                    }
                    sql += "  fk_Categoria_id_categoria = " + idCategoria + " ";
                }
                
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    while (dr.Read())
                    {
                        Produto tempProduto = new Produto();
                        tempProduto.IdProduto = Int32.Parse(dr["id_produto"].ToString());
                        tempProduto.CodBarras = Int32.Parse(dr["cod_barras_produto"].ToString());
                        tempProduto.NomeProduto = dr["nome_produto"].ToString();
                        tempProduto.DescricaoProduto = dr["descr_produto"].ToString();
                        tempProduto.PrecoUnitarioConvertido = dr["precoFormatado"].ToString();
                        tempProduto.QuantEstoque = Int32.Parse(dr["quant_produto"].ToString());
                        tempProduto.QuantMinimaEstoque = Int32.Parse(dr["quant_min_produto"].ToString());
                        tempProduto.ImgProduto = dr["img_produto"].ToString();
                        //necessidade de instanciar um objeto categoria e fornecedor para passar os IDs no objeto prod
                        tempProduto.Categoria = new Categoria
                        {
                            IdCategoria = Int32.Parse(dr["fk_Categoria_id_categoria"].ToString())
                        };
                        tempProduto.Fornecedor = new Fornecedor
                        {
                            IdFornecedor = Int32.Parse(dr["fk_Fornecedor_id_fornec"].ToString())
                        };

                        produtos.Add(tempProduto);
                    }
                }
                else
                {
                    produtos = null;
                    return produtos;
                }
                return produtos;
            }
            catch (Exception erro)
            {
                produtos = null;
                return produtos;
            }
        }

        public List<Produto> listarProdutos()
        {
            List<Produto> produtos = new List<Produto>();
            string sql;
            try
            {
                sql = "SELECT id_produto, cod_barras_produto, nome_produto, descr_produto, precUnit_produto, format(precUnit_produto, 'C', 'pt-br') as precoFormatado, quant_produto, quant_min_produto, img_produto, fk_Categoria_id_categoria, fk_Fornecedor_id_fornec FROM Produto";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    while (dr.Read())
                    {
                        Produto tempProduto = new Produto();
                        tempProduto.IdProduto = Int32.Parse(dr["id_produto"].ToString());
                        tempProduto.CodBarras = Int32.Parse(dr["cod_barras_produto"].ToString());
                        tempProduto.NomeProduto = dr["nome_produto"].ToString();
                        tempProduto.DescricaoProduto = dr["descr_produto"].ToString();
                        tempProduto.PrecoUnitarioConvertido = dr["precoFormatado"].ToString();
                        tempProduto.QuantEstoque = Int32.Parse(dr["quant_produto"].ToString());
                        tempProduto.QuantMinimaEstoque = Int32.Parse(dr["quant_min_produto"].ToString());
                        tempProduto.ImgProduto = dr["img_produto"].ToString();
                        //necessidade de instanciar um objeto categoria e fornecedor para passar os IDs no objeto prod
                        tempProduto.Categoria = new Categoria
                        {
                            IdCategoria = Int32.Parse(dr["fk_Categoria_id_categoria"].ToString())
                        };
                        tempProduto.Fornecedor = new Fornecedor
                        {
                            IdFornecedor = Int32.Parse(dr["fk_Fornecedor_id_fornec"].ToString())
                        };

                        produtos.Add(tempProduto);
                    }
                }
                else
                {
                    produtos = null;
                    return produtos;
                }
                return produtos;
            }
            catch (Exception erro)
            {
                produtos = null;
                return produtos;
            }
        }
    }
}