﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class EnderecoDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        //instanciando classe EnderecoDAO e realizando conexão
        public EnderecoDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Endereco buscarEnderecoPedido(int id)
        {
            Endereco endereco = new Endereco();
            string sql = "";

            try
            {
                sql = "SELECT nome_enderec, numero_enderec, cep_enderec, bairro_enderec, compl_enderec ";
                sql += " FROM Pedido INNER JOIN Endereco ON fk_Endereco_id_enderec = id_enderec ";
                sql += " WHERE id_pedido = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    endereco.NomeEndereco = dr["nome_enderec"].ToString();
                    endereco.NumeroEndereco = Int32.Parse(dr["numero_enderec"].ToString());
                    endereco.CepEndereco = dr["cep_enderec"].ToString();
                    endereco.BairroEndereco = dr["bairro_enderec"].ToString();
                    endereco.Complemento = dr["compl_enderec"].ToString();
                }
                else
                {
                    endereco.NomeEndereco = "Sem retorno de endereços";
                }
            }
            catch (Exception erro)
            {
                endereco.NomeEndereco = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return endereco;
        }

        public Endereco buscarEnderecosUsuario(int id)
        {
            Endereco endereco = new Endereco();
            string sql = "";

            try
            {
                sql = "SELECT nome_enderec, numero_enderec, cep_enderec, bairro_enderec, compl_enderec ";
                sql += " FROM Endereco  WHERE id_enderec = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    endereco.NomeEndereco = dr["nome_enderec"].ToString();
                    endereco.NumeroEndereco = Int32.Parse(dr["numero_enderec"].ToString());
                    endereco.CepEndereco = dr["cep_enderec"].ToString();
                    endereco.BairroEndereco = dr["bairro_enderec"].ToString();
                    endereco.Complemento = dr["compl_enderec"].ToString();
                }
                else
                {
                    endereco.NomeEndereco = "Sem retorno de endereços";
                }
            }
            catch (Exception erro)
            {
                endereco.NomeEndereco = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return endereco;
        }

        public string cadastrarEndereco(Endereco endereco)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "INSERT INTO Endereco (nome_enderec, bairro_enderec, numero_enderec, cep_enderec, compl_enderec, fk_Usuario_id_usu, ativo_enderec) ";
                sql += "VALUES ('" + endereco.NomeEndereco + "', '" + endereco.BairroEndereco + "', " + endereco.NumeroEndereco + ", '" + endereco.CepEndereco + "', '" + endereco.Complemento + "', " + endereco.Cliente.IdUsuario + ", 1)";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }

            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
    
        public string alterarEndereco(Endereco endereco)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Endereco SET nome_enderec = '" + endereco.NomeEndereco + "', bairro_enderec = '" + endereco.BairroEndereco + "', numero_enderec = " + endereco.NumeroEndereco + ", cep_enderec = '" + endereco.CepEndereco + "', compl_enderec = '" + endereco.Complemento + "' ";
                sql += " WHERE id_enderec = " + endereco.IdEndereco;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirEndereco(int idEndereco)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Endereco SET ativo_enderec = 0  WHERE id_enderec = " + idEndereco;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
    }
}