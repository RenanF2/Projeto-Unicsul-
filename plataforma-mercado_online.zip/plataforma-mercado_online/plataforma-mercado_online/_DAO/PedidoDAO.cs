﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class PedidoDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public PedidoDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public int criarPedido(Pedido pedido)
        {
            int resp = 0, retorno;
            string sql = "";
            try
            {
                sql = "INSERT INTO Pedido (fk_Usuario_id_usu, fk_Status_id_status, total_pedido) ";
                sql += " VALUES (" + pedido.Cliente.IdUsuario + ", " + pedido.IdStatus + ", 0)";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return pedido.IdPedido;
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception erro)
            {
                resp = -1;
            }
            return resp;
        }

        public string adicionarItem(int idPedido, Produto produto, int quant)
        {
            string resp, sql = "";
            int retorno;
            double subTotal;
            try
            {
                subTotal = produto.PrecoUnitario * quant;
                string subTotalConvertido = subTotal.ToString().Replace(',', '.');
                sql = "INSERT INTO Item_possui (fk_Produto_id_produto, fk_Pedido_id_pedido, quantidade_item, subTotal_item) VALUES(" + produto.IdProduto + ", " + idPedido + ", " + quant + ", " + subTotalConvertido + ")";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    atualizarValorPedido(idPedido, subTotal);
                    atualizarStatusPedido(idPedido, 2);
                    return "adicionado";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }

            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }

            return resp;
        }

        public string atualizarStatusPedido(int idPedido, int codigoMudanca)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "UPDATE Pedido SET fk_Status_id_status = " + codigoMudanca + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na atualização - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string atualizarValorPedido(int idPedido, double valor)
        {
            string resp, sql = "", valorConvertido = valor.ToString().Replace(',', '.');
            int retorno;
            try
            {
                sql = "UPDATE Pedido SET total_pedido += " + valorConvertido + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na atualização do preço do pedido - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarItemPedido(int idPedido, Produto item, int quantidadeItem)
        {
            string resp = "", sql = "";
            double subTotalAntigo = 0, subTotalNovo = 0;
            int retorno;
            try
            {
                subTotalAntigo = item.SubTotalItem;
                subTotalNovo = item.PrecoUnitario * quantidadeItem;
                sql = "UPDATE Item_possui SET subTotal_item = " + subTotalNovo.ToString().Replace(',', '.') + ", quantidade_item = " + quantidadeItem;
                sql += " WHERE fk_Pedido_id_pedido = " + idPedido + " AND fk_Produto_id_produto = " + item.IdProduto;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    resp = "Ok";
                }
                else
                {
                    resp = "Erro na atualização do preço do item - Comando: " + sql;
                }

                if (resp == "Ok")
                {
                    sql = "UPDATE Pedido SET total_pedido = total_pedido + " + subTotalNovo.ToString().Replace(',', '.') + " - " + subTotalAntigo.ToString().Replace(',', '.') + " WHERE id_pedido = " + idPedido;
                    cmd = new SqlCommand(sql, conexao);
                    retorno = cmd.ExecuteNonQuery();

                    if (retorno > 0)
                    {
                        return "Ok";
                    }
                    else
                    {
                        return "Erro na atualização do preço do pedido - Comando: " + sql;
                    }
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string adicionarFormaPagamento(int idPedido, int codigoPagamento)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "UPDATE Pedido SET fk_Forma_pagamento_id_metodo = " + codigoPagamento + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na adição - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string adicionarFormaEntrega(int idPedido, int codigoEntrega)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "UPDATE Pedido SET fk_Forma_Entrega_id_entrega = " + codigoEntrega + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na adição - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
        
        public string adicionarEnderecoEntrega(int idPedido, int codigoEndereco)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "UPDATE Pedido SET fk_Endereco_id_enderec = " + codigoEndereco + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na adição - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string adicionarFuncionario(int idPedido, int idFuncionario)
        {
            string resp, sql = "";
            int retorno;
            try
            {
                sql = "INSERT INTO Pedido_Funcionario_prepara (fk_Funcionario_id_func, fk_Pedido_id_pedido) VALUES(" + idFuncionario + ", " + idPedido + ")";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na adição do funcionário no pedido - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Pedido pesquisarPedido(int id)
        {
            Pedido pedidoAtivo = new Pedido();
            string sql = "";
            try
            {
                sql = "SELECT id_pedido, fk_Status_id_status, fk_Forma_Entrega_id_entrega, fk_Forma_pagamento_id_metodo, fk_Usuario_id_usu, fk_Endereco_id_enderec, total_pedido, format(total_pedido, 'C', 'pt-br') as precoFormatado FROM Pedido WHERE fk_Status_id_status NOT IN (10, 99) AND id_pedido = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    pedidoAtivo.IdPedido = Int32.Parse(dr["id_pedido"].ToString());
                    pedidoAtivo.IdStatus = Int32.Parse(dr["fk_Status_id_status"].ToString());
                    pedidoAtivo.IdEntrega = Int32.Parse(dr["fk_Forma_Entrega_id_entrega"].ToString());
                    pedidoAtivo.IdPagamento = Int32.Parse(dr["fk_Forma_pagamento_id_metodo"].ToString());
                    pedidoAtivo.Cliente = new Usuario 
                    {
                        IdUsuario = Int32.Parse(dr["fk_Usuario_id_usu"].ToString())
                    };
                    pedidoAtivo.Endereco = new Endereco
                    {
                        IdEndereco = Int32.Parse(dr["fk_Endereco_id_enderec"].ToString())
                    };
                    pedidoAtivo.ValorTotal = Double.Parse(dr["total_pedido"].ToString());
                    pedidoAtivo.ValorTotalConvertido = dr["precoFormatado"].ToString();
                }
                else
                {
                    pedidoAtivo.IdPedido = 0;
                }
                return pedidoAtivo;
            }
            catch (Exception erro)
            {
                //pedidoAtivo.Endereco.NomeEndereco = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return pedidoAtivo;
        }

        public Pedido pesquisarPedidoAtivo(int id)
        {
            Pedido pedidoAtivo = new Pedido();
            string sql = "";
            try
            {
                sql = "SELECT id_pedido, total_pedido, fk_Forma_Entrega_id_entrega, fk_Forma_pagamento_id_metodo, fk_Usuario_id_usu, fk_Status_id_status, fk_Endereco_id_enderec, format(total_pedido, 'C', 'pt-br') as precoFormatado FROM Pedido WHERE fk_Status_id_status NOT IN (10, 99) AND fk_Usuario_id_usu = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    pedidoAtivo.IdPedido = Int32.Parse(dr["id_pedido"].ToString());
                    pedidoAtivo.IdStatus = Int32.Parse(dr["fk_Status_id_status"].ToString());
                    pedidoAtivo.ValorTotal = Double.Parse(dr["total_pedido"].ToString());
                    pedidoAtivo.ValorTotalConvertido = dr["precoFormatado"].ToString();
                    pedidoAtivo.IdEntrega = Int32.Parse(dr["fk_Forma_Entrega_id_entrega"].ToString());
                    pedidoAtivo.IdPagamento = Int32.Parse(dr["fk_Forma_pagamento_id_metodo"].ToString());
                    pedidoAtivo.Cliente = new Usuario
                    {
                        IdUsuario = Int32.Parse(dr["fk_Usuario_id_usu"].ToString())
                    };
                    pedidoAtivo.Endereco = new Endereco
                    {
                        IdEndereco = Int32.Parse(dr["fk_Endereco_id_enderec"].ToString())
                    };
                }
                else
                {
                    pedidoAtivo.IdPedido = 0;
                }
                return pedidoAtivo;
            }
            catch (Exception erro)
            {
                //pedidoAtivo.Endereco.NomeEndereco = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return pedidoAtivo;
        }
        
        public string atualizarQuantidadeItem(int idPedido, int idProduto, int quantidade, double valor)
        {
            string resp, sql = "";
            int retorno;
            Produto produto = new ProdutoDAO().pesquisarProduto(idProduto);
            double subTotal = produto.PrecoUnitario * quantidade;
            string subTotalConvertido = subTotal.ToString().Replace(',', '.');
            try
            {
                sql = "UPDATE Item_possui SET quantidade_item = " + quantidade + ", subTotal_item =" + subTotalConvertido + " WHERE fk_Pedido_id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "Ok";
                }
                else
                {
                    return "Erro na atualização do preço do pedido - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public List<Produto> carregarItensPedido(int id)
        {
            List<Produto> itensPedido = new List<Produto>();
            string sql = "";
            try
            {
                sql = "SELECT fk_Produto_id_produto, cod_barras_produto, nome_produto, quantidade_item, subTotal_item, precUnit_produto ";
                sql += " FROM Item_possui item INNER JOIN Produto ON item.fk_Produto_id_produto = Produto.id_produto ";
                sql += " INNER JOIN Pedido ON item.fk_Pedido_id_pedido = Pedido.id_pedido ";
                sql += " WHERE fk_Pedido_id_pedido = " + id + " AND fk_Status_id_status NOT IN (10, 99)";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while(dr.Read())
                    {
                        Produto tempProduto = new Produto();

                        tempProduto.IdProduto = Int32.Parse(dr["fk_Produto_id_produto"].ToString());
                        tempProduto.CodBarras = Int32.Parse(dr["cod_barras_produto"].ToString());
                        tempProduto.NomeProduto = dr["nome_produto"].ToString();
                        tempProduto.QuantidadeItem = Int32.Parse(dr["quantidade_item"].ToString());
                        tempProduto.SubTotalItem = Double.Parse(dr["subTotal_item"].ToString());
                        tempProduto.PrecoUnitario = Double.Parse(dr["precUnit_produto"].ToString());

                        itensPedido.Add(tempProduto);
                    }
                }

            }
            catch (Exception ex)
            {
                
            }

            return itensPedido;
        }
    
        public string atualizarEstoque(List<Produto> itensPedido)
        {
            string sql = "", resp = "";
            int retorno;
            try
            {
                foreach(Produto item in itensPedido)
                {
                    sql = "UPDATE Produto SET quant_produto -= " + item.QuantidadeItem + " WHERE id_produto = " + item.IdProduto;
                    cmd = new SqlCommand(sql, conexao);
                    retorno = cmd.ExecuteNonQuery();

                    if (retorno > 0)
                    {
                        resp = "Ok";
                    }
                    else
                    {
                        return "Erro na atualização de estoque - Comando: " + sql;
                    }
                }
                return resp;
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
    
        public string excluirItemPedido(int idPedido, Produto item)
        {
            string resp = "", sql = "";
            double subTotal = 0;
            int retorno;
            try
            {
                subTotal = item.SubTotalItem;
                sql = "UPDATE Pedido SET total_pedido -= " + subTotal.ToString().Replace(',', '.') + " WHERE id_pedido = " + idPedido;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    resp = "Ok";
                }
                else
                {
                    resp = "Erro na atualização do valor do pedido - Comando: " + sql;
                }

                if (resp == "Ok")
                {
                    sql = "DELETE FROM Item_possui WHERE fk_Pedido_id_pedido = " + idPedido + " AND fk_Produto_id_produto = " + item.IdProduto;
                    cmd = new SqlCommand(sql, conexao);
                    retorno = cmd.ExecuteNonQuery();

                    if (retorno > 0)
                    {
                        return "Ok";
                    }
                    else
                    {
                        return "Erro na exclusão do item - Comando: " + sql;
                    }
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
    }
}