﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class Cargo_FuncionarioDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        //instanciando classe Cargo_FuncionarioDAO e realizando conexão
        public Cargo_FuncionarioDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Métodos com uso de comandos sql e do objeto Cargo_Funcionario
        public string gravarCargo(Cargo_Funcionario cargo)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Cargo_Funcionario (id_cargo, nome_cargo, descr_cargo) VALUES (" + cargo.IdCargo + ", '" + cargo.NomeCargo + "', '" + cargo.DescricaoCargo + "')";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarCargo(Cargo_Funcionario cargo)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Cargo_Funcionario SET nome_cargo = '" + cargo.NomeCargo + "', descr_cargo = '" + cargo.DescricaoCargo + "' ";
                sql += " WHERE id_cargo = " + cargo.IdCargo;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirCargo(int id)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "DELETE FROM Cargo_Funcionario WHERE id_cargo = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Cargo_Funcionario pesquisarCargo(int id)
        {
            Cargo_Funcionario cargo = new Cargo_Funcionario();
            string sql;

            try
            {
                sql = "SELECT id_cargo, nome_cargo, descr_cargo FROM Cargo_Funcionario WHERE id_cargo = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto cat
                    dr.Read();
                    cargo.IdCargo = Int32.Parse(dr["id_cargo"].ToString());
                    cargo.NomeCargo = dr["nome_cargo"].ToString();
                    cargo.DescricaoCargo = dr["descr_cargo"].ToString();

                    return cargo;
                }
                else
                {
                    cargo.NomeCargo = "Não existe esta categoria no sistema.";
                    return cargo;
                }
            }
            catch (Exception erro)
            {
                cargo.NomeCargo = "ERRO: " + erro.ToString();
                return cargo;
            }
        }

        //Método para validação de exclusao de linha da tabela, analisando as dependências da tabela
        public bool verificarDependenciasCargo(int id)
        {
            string sql;
            try
            {
                sql = "SELECT id_func,  id_cargo, nome_cargo FROM Funcionario f INNER JOIN Cargo_Funcionario c ON (c.id_cargo = f.fk_Cargo_Funcionario_id_cargo) WHERE c.id_cargo = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    if(Int32.Parse(dr["id_categoria"].ToString()) == 1)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception erro)
            {
                return false;
            }
        }

    }
}