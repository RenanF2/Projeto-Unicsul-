﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class CategoriaDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        //Comando para validação de exclusao de linha da tabela, analisando as dependências da tabela
        //SELECT id_produto FROM Produto p INNER JOIN Categoria c ON (c.id_categoria = p.fk_Categoria_id_categoria) WHERE c.id_categoria = 1

        //instanciando classe CategoriaDAO e realizando conexão
        public CategoriaDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Métodos com uso de comandos sql e do objeto Categoria
        public string gravarCategoia(Categoria categoria)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Categoria (id_categoria, nome_categoria, descr_categoria) VALUES (" + categoria.IdCategoria + ", '" + categoria.NomeCategoria + "', '" + categoria.DescricaoCategoria + "')";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarCategoria(Categoria categoria)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Categoria SET nome_categoria = '" + categoria.NomeCategoria + "', descr_categoria = '" + categoria.DescricaoCategoria + "' ";
                sql += " WHERE id_categoria = " + categoria.IdCategoria;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirCategoria(int id)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "DELETE FROM Categoria WHERE id_categoria = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Categoria pesquisarCategoria(int id)
        {
            Categoria cat = new Categoria();
            string sql;

            try
            {
                sql = "SELECT id_categoria, nome_categoria, descr_categoria FROM Categoria WHERE id_categoria = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto cat
                    dr.Read();
                    cat.IdCategoria = Int32.Parse(dr["id_categoria"].ToString());
                    cat.NomeCategoria = dr["nome_categoria"].ToString();
                    cat.DescricaoCategoria = dr["descr_categoria"].ToString();

                    return cat;
                }
                else
                {
                    cat.NomeCategoria = "Não existe este produto no sistema.";
                    return cat;
                }
            }
            catch (Exception erro)
            {
                cat.NomeCategoria = "ERRO: " + erro.ToString();
                return cat;
            }
        }

        /*public List<Categoria> listarCategorias()
        {
            List<Categoria> listCategoria = new List<Categoria>();
            return listCategoria;
        }*/

        public bool verificarDependenciasCategoria(int id)
        {
            string sql;

            try
            {
                sql = "SELECT id_produto FROM Produto p INNER JOIN Categoria c ON (c.id_categoria = p.fk_Categoria_id_categoria) WHERE c.id_categoria = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception erro)
            {
                return false;
            }
        }
    }
}