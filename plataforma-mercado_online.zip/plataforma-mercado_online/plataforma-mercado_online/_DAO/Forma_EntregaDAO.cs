﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class Forma_EntregaDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public Forma_EntregaDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Forma_Entrega pesquisarFormaEntrega(int id)
        {
            Forma_Entrega entrega = new Forma_Entrega();
            string sql;

            try
            {
                sql = "SELECT id_entrega, nome_entrega, descr_entrega FROM Forma_Entrega WHERE id_entrega = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    entrega.IdFormaEntrega = Int32.Parse(dr["id_entrega"].ToString());
                    entrega.NomeFormaEntrega = dr["nome_entrega"].ToString();
                    entrega.DescricaoFormaEntrega = dr["descr_entrega"].ToString();
                    return entrega;
                }
                else
                {
                    entrega.NomeFormaEntrega = "Não existe este Método de Entrega no sistema.";
                    return entrega;
                }
            }
            catch (Exception erro)
            {
                entrega.NomeFormaEntrega = "ERRO: " + erro.ToString();
                return entrega;
            }
        }
    }
}