﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class Forma_PagamentoDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public Forma_PagamentoDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Forma_Pagamento pesquisarFormaPagamento(int id)
        {
            Forma_Pagamento pag = new Forma_Pagamento();
            string sql;

            try
            {
                sql = "SELECT id_metodo, nome_metodo, descr_metodo FROM Forma_Pagamento WHERE id_metodo = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    pag.IdMetodoPag = Int32.Parse(dr["id_metodo"].ToString());
                    pag.NomeMetodoPag = dr["nome_metodo"].ToString();
                    pag.DescricaoMetodoPag = dr["descr_metodo"].ToString();
                    return pag;
                }
                else
                {
                    pag.NomeMetodoPag = "Não existe este método de pagamento no sistema.";
                    return pag;
                }
            }
            catch (Exception erro)
            {
                pag.NomeMetodoPag = "ERRO: " + erro.ToString();
                return pag;
            }
        }
    }
}