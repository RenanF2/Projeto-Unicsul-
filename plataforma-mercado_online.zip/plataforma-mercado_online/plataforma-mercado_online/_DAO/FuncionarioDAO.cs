﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class FuncionarioDAO
    {
        //conexão com o banco de dados e variáveis para comandos sql
        //Testar variável conexao, verificar se o caminho está funcionando em outras máquinas
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        //SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='C:\Users\André Barbosa\Desktop\Faculdade Unicsul\4º Semestre\Projeto Interdisciplinar III\Prototipos\Prototipo_v1\plataforma - mercado_online\plataforma - mercado_online\_BD\Comercio.mdf';Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataReader dr;

        //Método construdor, instanciando classe FuncionarioDAO e realizando conexão
        public FuncionarioDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string gravarFuncionario(Funcionario funcionario)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Funcionario (id_func, nome_func, cpf_func, senha_func, email_func, salario_func, tel_func, fk_Cargo_Funcionario_id_cargo) ";
                sql += "VALUES (" + funcionario.IdFuncionario + ", '" + funcionario.NomeFuncionario + "', '" + funcionario.CpfFuncionario + "', '" + funcionario.SenhaFuncionario + "', '" + funcionario.EmailFuncionario + "', " + funcionario.SalarioFuncionario + ", '" + funcionario.TelefoneFuncionario + "', " + funcionario.Cargo.IdCargo + ")";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }

            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarFuncionario(Funcionario funcionario)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Funcionario SET nome_func = '" + funcionario.NomeFuncionario + "', senha_func = '" + funcionario.SenhaFuncionario + "', email_func = '" + funcionario.EmailFuncionario + "', salario_func = " + funcionario.SalarioFuncionario + ", tel_func = " + funcionario.TelefoneFuncionario + ", ";
                sql += " fk_Cargo_Funcionario_id_cargo = " + funcionario.Cargo.IdCargo + " ";
                sql += " WHERE id_func = " + funcionario.IdFuncionario;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirFuncionario(int id)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "DELETE FROM Funcionario WHERE id_func = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Funcionario pesquisarFuncionario(int id)
        {
            Funcionario funcionario = new Funcionario();
            string sql;

            try
            {
                sql = "SELECT id_func, nome_func, cpf_func, senha_func, email_func, salario_func, tel_func, fk_Cargo_Funcionario_id_cargo FROM Funcionario WHERE id_func = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    funcionario.IdFuncionario = Int32.Parse(dr["id_func"].ToString());
                    funcionario.NomeFuncionario = dr["nome_func"].ToString();
                    funcionario.CpfFuncionario = dr["cpf_func"].ToString();
                    funcionario.SenhaFuncionario = dr["senha_func"].ToString();
                    funcionario.EmailFuncionario = dr["email_func"].ToString();
                    funcionario.SalarioFuncionario = Int32.Parse(dr["salario_func"].ToString());
                    funcionario.TelefoneFuncionario = dr["tel_func"].ToString();
                    //necessidade de instanciar um objeto Cargo_Funcionario para passar o ID no objeto funcionario
                    funcionario.Cargo = new Cargo_Funcionario
                    {
                        IdCargo = Int32.Parse(dr["fk_Cargo_Funcionario_id_cargo"].ToString())
                    };

                    return funcionario;
                }
                else
                {
                    funcionario.NomeFuncionario = "Não existe este funcionário no sistema.";
                    return funcionario;
                }
            }
            catch (Exception erro)
            {
                funcionario.NomeFuncionario = "ERRO: " + erro.ToString();
                return funcionario;
            }
        }

        public Funcionario fazerLoginFuncionario(string cpf, string senha)
        {
            Funcionario funcionario = new Funcionario();
            string sql;

            try
            {
                sql = "SELECT id_func, fk_Cargo_Funcionario_id_cargo FROM Funcionario WHERE cpf_func = '" + cpf + "' AND senha_func = '" + senha + "'";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    funcionario.IdFuncionario = Int32.Parse(dr["id_func"].ToString());
                    funcionario.Cargo = new Cargo_Funcionario
                    {
                        IdCargo = Int32.Parse(dr["fk_Cargo_Funcionario_id_cargo"].ToString())
                    };
                    return funcionario;
                }
                else
                {
                    funcionario.IdFuncionario = 0;
                    return funcionario;
                }
            }
            catch (Exception erro)
            {
                funcionario.IdFuncionario = 0;
                return funcionario;
            }
        }

        public bool verificarCPF(string cpf)
        {
            string sql;

            try
            {
                sql = "SELECT id_func, nome_func, cpf_func FROM Funcionario WHERE cpf_func = '" + cpf + "'";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception erro)
            {
                return false;
            }
        }
    }
}