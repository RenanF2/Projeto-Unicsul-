﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class UsuarioDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public UsuarioDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string gravarUsuario(Usuario usuario)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Usuario (nome_usu, cpf_usu, email_usu, senha_usu, dtNasc_usu, tel_usu) ";
                sql += " VALUES ('" + usuario.NomeUsuario + "', '" + usuario.CpfUsuario + "', '" + usuario.EmailUsuario + "', '" + usuario.SenhaUsuario + "', '" + usuario.DtNascimentoUsuario.ToShortDateString() + "', '" + usuario.TelefoneUsuario + "')";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public Usuario fazerLoginUsuario(string email, string senha)
        {
            Usuario usuario = new Usuario();
            string sql;

            try
            {
                sql = "SELECT id_usu, nome_usu, cpf_usu FROM Usuario WHERE email_usu = '" + email + "' AND senha_usu = '" + senha + "'";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    usuario.IdUsuario = Int32.Parse(dr["id_usu"].ToString());
                    usuario.NomeUsuario = dr["nome_usu"].ToString();
                    usuario.CpfUsuario = dr["cpf_usu"].ToString();
                    return usuario;
                }
                else
                {
                    usuario.IdUsuario = 0;
                    return usuario;
                }
            }
            catch (Exception erro)
            {
                usuario.NomeUsuario = "ERRO: " + erro.ToString();
                return usuario;
            }
        }

        public bool verificarCPF(string cpf)
        {
            string sql;

            try
            {
                sql = "SELECT id_usu, nome_usu, cpf_usu FROM Usuario WHERE cpf_usu = '" + cpf + "'";
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception erro)
            {
                return false;
            }
        }
    
        public Usuario pesquisarUsuario(int id)
        {
            Usuario usuario = new Usuario();
            string sql;

            try
            {
                sql = "SELECT id_usu, nome_usu, cpf_usu, email_usu, tel_usu FROM Usuario WHERE id_usu = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    //lendo retorno e passando os valores retornados para o objeto prod
                    dr.Read();
                    usuario.IdUsuario = Int32.Parse(dr["id_usu"].ToString());
                    usuario.NomeUsuario = dr["nome_usu"].ToString();
                    usuario.CpfUsuario = dr["cpf_usu"].ToString();
                    usuario.EmailUsuario = dr["email_usu"].ToString();
                    usuario.TelefoneUsuario = dr["tel_usu"].ToString();
                    return usuario;
                }
                else
                {
                    usuario.IdUsuario = 0;
                    usuario.NomeUsuario = "Sem resultados de usuários";
                    return usuario;
                }
            }
            catch (Exception erro)
            {
                usuario.NomeUsuario = "ERRO: " + erro.ToString();
                return usuario;
            }
        }
    }
}