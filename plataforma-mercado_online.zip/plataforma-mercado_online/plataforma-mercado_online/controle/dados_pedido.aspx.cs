﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class daods_pedido : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
            carregarMenu();

            int id = Int32.Parse(Request["id"]);

            SqlDataSourceItensPedido.SelectCommand += " WHERE id_pedido = " + id;
            SqlDataSourceItensPedido.DataBind();
            gdvItens.DataBind();
        }

        protected void btnFinalizarPreparacao_Click(object sender, EventArgs e)
        {
            string resposta = "";
            int idFuncionario = Int32.Parse(Session["id_funcionario"].ToString());
            int id = Int32.Parse(Request["id"]);

            List<Produto> itensPedido = new PedidoDAO().carregarItensPedido(id);
            resposta = new PedidoDAO().atualizarEstoque(itensPedido);
            resposta = new PedidoDAO().adicionarFuncionario(id, idFuncionario);
            resposta = new PedidoDAO().atualizarStatusPedido(id, 7);

            Pedido pedido = new PedidoDAO().pesquisarPedido(id);

            if(pedido.IdEntrega == 1)
            {
                resposta = new PedidoDAO().atualizarStatusPedido(id, 8);
            }

            if (pedido.IdEntrega == 2)
            {
                resposta = new PedidoDAO().atualizarStatusPedido(id, 9);
            }

            if(resposta == "Ok")
            {
                Server.Transfer("menu_pedidos.aspx");
            }
        }

        protected void btnInformarProblema_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(Request["id"]);
            string resposta = new PedidoDAO().atualizarStatusPedido(id, 99);

            if (resposta == "Ok")
            {
                Server.Transfer("menu_pedidos.aspx");
            }
        }

        void carregarMenu()
        {
            string cargo = Session["cargo"].ToString();

            switch (cargo)
            {
                case "2":
                    link_funcionario.Visible = false;
                    link_fornecedor.Visible = false;
                    break;

                case "3":
                    Server.Transfer("menu_gestao.aspx");
                    break;
            }
        }
    }
}