﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class frmFornecedor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //IsPostBack para pegar qualquer alteração feita nos campos e na página, mandando sempre os dados atualizados, principalmente no update
            if (!Page.IsPostBack)
            {
                if (Request["operacao"] != null)
                {
                    //recebe o dado da operação a ser realizada, vindo dos links de atualização ou exclusão de um fornecedor do menu_fornecedores.aspx
                    string operacao = Request["operacao"].ToString();

                    //dependendo da operação, irá bloquear os campos q não podem ser alterados para determinada operação
                    if (operacao == "A")
                    {
                        txtIdFornecedor.Enabled = false;

                        btnFinalizarFornecedor.Text = "Alterar";
                        preencherCamposFornecedor();
                    }

                    if (operacao == "E")
                    {
                        txtIdFornecedor.Enabled = false;
                        txtNomeFornecedor.Enabled = false;
                        txtCnpjFornecedor.Enabled = false;
                        txtEmailFornecedor.Enabled = false;
                        txtEnderecoFornecedor.Enabled = false;
                        txtTelefoneFornecedor.Enabled = false;

                        btnFinalizarFornecedor.Text = "Excluir";
                        preencherCamposFornecedor();
                    }
                }

                if (Request["id"] != null)
                {
                    txtIdFornecedor.Text = Request["id"].ToString();
                }
            }
        }

        protected void btnFinalizarFornecedor_Click(object sender, EventArgs e)
        {
            Fornecedor forn = new Fornecedor(Int32.Parse(txtIdFornecedor.Text), txtNomeFornecedor.Text, txtCnpjFornecedor.Text, txtEnderecoFornecedor.Text, txtEmailFornecedor.Text, txtTelefoneFornecedor.Text);
            string resposta;

            if (Request["operacao"] != null)
            {
                string operacao = Request["operacao"].ToString();
                if (operacao == "A")
                {
                    resposta = new FornecedorDAO().alterarFornecedor(forn);
                }
                else if (operacao == "E")
                {
                    bool isDependencias = new FornecedorDAO().verificarDependenciasFornecedor(forn.IdFornecedor);
                    if (isDependencias == false)
                    {
                        resposta = new FornecedorDAO().excluirFornecedor(forn.IdFornecedor);
                    }
                    else
                    {
                        resposta = "";
                    }
                }
                else
                {
                    resposta = new FornecedorDAO().gravarFornecedor(forn);
                }
            }
            else
            {
                resposta = new FornecedorDAO().gravarFornecedor(forn);
            }

            if (resposta == "ok")
            {
                Response.Redirect("menu_fornecedores.aspx");
            }
        }

        void preencherCamposFornecedor()
        {
            Fornecedor fornSolicitado = new FornecedorDAO().pesquisarFornecedor(Int32.Parse(Request["id"]));

            txtNomeFornecedor.Text = fornSolicitado.NomeFornecedor;
            txtCnpjFornecedor.Text = fornSolicitado.CnpjFornecedor;
            txtEmailFornecedor.Text = fornSolicitado.EmailFornecedor;
            txtEnderecoFornecedor.Text = fornSolicitado.EnderecoFornecedor;
            txtTelefoneFornecedor.Text = fornSolicitado.TelefoneFornecedor;
        }
    }
}