﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class frmFuncionario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //IsPostBack para pegar qualquer alteração feita nos campos e na página, mandando sempre os dados atualizados, principalmente no update
            if (!Page.IsPostBack)
            {
                if (Request["operacao"] != null)
                {
                    //recebe o dado da operação a ser realizada, vindo dos links de atualização ou exclusão de um Funcionario do menu_funcionarios.aspx
                    string operacao = Request["operacao"].ToString();

                    //dependendo da operação, irá bloquear os campos q não podem ser alterados para determinada operação
                    if (operacao == "A")
                    {
                        txtIdFuncionario.Enabled = false;
                        txtCpfFuncionario.Enabled = false;

                        btnFinalizarFuncionario.Text = "Alterar";
                        preencherCampos();
                    }

                    if (operacao == "E")
                    {
                        txtIdFuncionario.Enabled = false;
                        txtNomeFuncionario.Enabled = false;
                        txtCpfFuncionario.Enabled = false;
                        txtSenhaFuncionario.Enabled = false;
                        txtEmailFuncionario.Enabled = false;
                        txtTelefoneFuncionario.Enabled = false;
                        txtSalarioFuncionario.Enabled = false;
                        ddlCargo.Enabled = false;

                        btnFinalizarFuncionario.Text = "Excluir";
                        preencherCampos();
                    }
                }

                if (Request["id"] != null)
                {
                    txtIdFuncionario.Text = Request["id"].ToString();
                }
            }
        }

        protected void btnFinalizarFuncionario_Click(object sender, EventArgs e)
        {
            Cargo_Funcionario cargo = new Cargo_Funcionario(Int32.Parse(ddlCargo.SelectedValue), null, null);
            Funcionario func = new Funcionario(Int32.Parse(txtIdFuncionario.Text), txtNomeFuncionario.Text, txtCpfFuncionario.Text, txtSenhaFuncionario.Text, txtTelefoneFuncionario.Text, txtEmailFuncionario.Text, Double.Parse(txtSalarioFuncionario.Text), cargo);
            string resposta;

            //executa uma ação a partir de uma determinada operação, se não for passado nenhum valor ou for um incorreto, o botão executa a ação de inserção por padrão
            if (Request["operacao"] != null)
            {
                string operacao = Request["operacao"].ToString();

                if (operacao == "A")
                {
                    resposta = new FuncionarioDAO().alterarFuncionario(func);
                }
                else if (operacao == "E")
                {
                    resposta = new FuncionarioDAO().excluirFuncionario(func.IdFuncionario);
                }
                else
                {
                    resposta = new FuncionarioDAO().gravarFuncionario(func);
                }
            }
            else
            {
                resposta = new FuncionarioDAO().gravarFuncionario(func);
            }

            //Ser houver uma resposta para operação, retorna para o menu de produtos
            if (resposta == "ok")
            {
                Response.Redirect("menu_funcionarios.aspx");
            }

        }

        void preencherCampos()
        {
            //método para preencher os campos com os dados do funcionario selecionado no GridView da página menu_funcionarios
            Funcionario funcSolicitado = new FuncionarioDAO().pesquisarFuncionario(Int32.Parse(Request["id"]));

            txtIdFuncionario.Text = funcSolicitado.IdFuncionario.ToString();
            txtNomeFuncionario.Text = funcSolicitado.NomeFuncionario.ToString();
            txtCpfFuncionario.Text = funcSolicitado.CpfFuncionario.ToString();
            txtSenhaFuncionario.Text = funcSolicitado.SenhaFuncionario.ToString();
            txtEmailFuncionario.Text = funcSolicitado.EmailFuncionario.ToString();
            txtTelefoneFuncionario.Text = funcSolicitado.TelefoneFuncionario.ToString();
            txtSalarioFuncionario.Text = funcSolicitado.SalarioFuncionario.ToString();
            ddlCargo.SelectedValue = funcSolicitado.Cargo.IdCargo.ToString();
        }
    }
}