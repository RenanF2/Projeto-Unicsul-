﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_gestao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }

            if (Boolean.Parse(Session["logado"].ToString()) == true && Session["cargo"] != null)
            {
                string cargo = Session["cargo"].ToString();

                switch (cargo)
                {
                    case "1":
                        txtCargo.Text = "Gerente";
                        break;

                    case "2":
                        txtCargo.Text = "Atendente";
                        linkFuncionarios.Visible = false;
                        linkFornecedores.Visible = false;
                        link_funcionario.Visible = false;
                        link_fornecedor.Visible = false;
                        break;

                    case "3":
                        txtCargo.Text = "Entregador";
                        linkCategorias.Visible = false;
                        linkProdutos.Visible = false;
                        linkFuncionarios.Visible = false;
                        linkFornecedores.Visible = false;
                        link_categoria.Visible = false;
                        link_produto.Visible = false;
                        link_funcionario.Visible = false;
                        link_fornecedor.Visible = false;
                        break;
                }
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            //IGNORAR ESSE MÉTODO
            Session["logado"] = false;
            Server.Transfer("frmLogin.aspx");
        }

        protected void btnLogout_Click1(object sender, EventArgs e)
        {
            Session["logado"] = false;
            Session["cargo"] = null;
            Session["id_funcionario"] = null;
            Server.Transfer("frmLogin.aspx");
        }
    }
}