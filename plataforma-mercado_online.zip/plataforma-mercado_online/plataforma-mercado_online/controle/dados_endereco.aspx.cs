﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class dados_endereco : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
            string cargo = Session["cargo"].ToString();

            if(cargo == "2")
            {
                Server.Transfer("menu_gestao.aspx");
            }
            int id = Int32.Parse(Request["id"]);
            int idCliente = Int32.Parse(Request["idCliente"]);

            Pedido pedido = new PedidoDAO().pesquisarPedido(id);
            Endereco endereco = new EnderecoDAO().buscarEnderecoPedido(id);
            Usuario usuario = new UsuarioDAO().pesquisarUsuario(idCliente);

            info_nome.InnerText = usuario.NomeUsuario;
            info_cpf.InnerText = "CPF: " + usuario.CpfUsuario;
            info_nome_endereco.InnerText = endereco.NomeEndereco + ", " + endereco.NumeroEndereco;
            info_cep.InnerText = "CEP: " + endereco.CepEndereco;
            info_bairro.InnerText = "Bairro: " + endereco.BairroEndereco;
            info_complemento.InnerText = "Compl.: " + endereco.Complemento;
            info_id_pedido.InnerText = "Código do pedido: " + pedido.IdPedido.ToString();
            info_valor_total.InnerText = "Preço: " + pedido.ValorTotalConvertido;
        }

        protected void btnFinalizarEntrega_Click(object sender, EventArgs e)
        {
            string resposta;
            int idFuncionario = Int32.Parse(Session["id_funcionario"].ToString());
            int id = Int32.Parse(Request["id"]);

            resposta = new PedidoDAO().adicionarFuncionario(id, idFuncionario);
            resposta = new PedidoDAO().atualizarStatusPedido(id, 10);

            if(resposta == "Ok")
            {
                Server.Transfer("menu_pedidos.aspx");
            }
        }

        protected void btnInformarProblema_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(Request["id"]);
            string resposta = new PedidoDAO().atualizarStatusPedido(id, 99);

            if (resposta == "Ok")
            {
                Server.Transfer("menu_pedidos.aspx");
            }
        }
    }
}