﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_pedidos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }

            if (Boolean.Parse(Session["logado"].ToString()) == true && Session["cargo"] != null)
            {
                carregarMenu();

                string cargo = Session["cargo"].ToString();
                string sql = SqlDataSourcePedidos.SelectCommand;

                switch (cargo)
                {
                    case "1":
                        sql = "SELECT id_pedido as ID, nome_usu Cliente, cpf_usu CPF, format(total_pedido, 'C', 'pt-br') as Valor, CONCAT(nome_enderec, ', ', numero_enderec) Endereço, nome_status, '---' AS Comandos ";
                        sql += " FROM Pedido p INNER JOIN Usuario ON p.fk_Usuario_id_usu = id_usu INNER JOIN Endereco e ON p.fk_Endereco_id_enderec = id_enderec INNER JOIN Status s ON p.fk_Status_id_status = id_status";
                        sql += " WHERE fk_Status_id_status IN (5, 6, 7, 8, 9, 10, 99) ";
                        break;

                    case "2":
                        sql += " WHERE fk_Status_id_status = 5 ";
                        break;

                    case "3":
                        sql = "SELECT id_pedido as ID, nome_usu Cliente, cpf_usu CPF, format(total_pedido, 'C', 'pt-br') as Valor, CONCAT(nome_enderec, ', ', numero_enderec) Endereço, nome_status, '<a href=dados_endereco.aspx?id=' + CAST(id_pedido as VARCHAR(8)) + '&idCliente=' + CAST(id_usu as VARCHAR(8)) + '>Visualizar</a>' AS Comandos ";
                        sql += " FROM Pedido p INNER JOIN Usuario ON p.fk_Usuario_id_usu = id_usu INNER JOIN Endereco e ON p.fk_Endereco_id_enderec = id_enderec INNER JOIN Status s ON p.fk_Status_id_status = id_status";
                        sql += " WHERE fk_Status_id_status = 8 ";
                        break;
                }

                SqlDataSourcePedidos.SelectCommand = sql;
                SqlDataSourcePedidos.DataBind();
                gdvPedidos.DataBind();

                if (gdvPedidos.Rows.Count <= 0)
                {
                    lblResposta.Text = "Não há pedidos para listar";
                    lblResposta.Visible = true;
                }
                else
                {
                    lblResposta.Visible = false;
                }
            }
        }

        void carregarMenu()
        {
            string cargo = Session["cargo"].ToString();

            switch (cargo)
            {
                case "2":
                    link_funcionario.Visible = false;
                    link_fornecedor.Visible = false;
                    break;

                case "3":
                    link_categoria.Visible = false;
                    link_produto.Visible = false;
                    link_funcionario.Visible = false;
                    link_fornecedor.Visible = false;
                    break;
            }
        }
    }
}