﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class frmEndereco : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["dadosUsuario"] != null)
            {
                if (!Page.IsPostBack)
                {
                    if (Request["operacao"] != null)
                    {
                        //recebe o dado da operação a ser realizada, vindo dos links de atualização ou exclusão de um produto do menu_produtos.aspx
                        string operacao = Request["operacao"].ToString();

                        //dependendo da operação, irá bloquear os campos q não podem ser alterados para determinada operação
                        if (operacao == "A")
                        {
                            btnSalvarEndereco.Text = "Alterar";
                            preencherCampos();
                        }

                        if (operacao == "E")
                        {
                            txtLocalEndereco.Enabled = false;
                            txtBairroEndereco.Enabled = false;
                            txtNumeroEndereco.Enabled = false;
                            txtCepEndereco.Enabled = false;
                            txtComplemento.Enabled = false;

                            btnSalvarEndereco.Text = "Excluir";
                            preencherCampos();
                        }
                    }
                }
            }
            else
            {
                Server.Transfer("pagina_cadastro_usuario.aspx");
            }
        }

        protected void btnSalvarEndereco_Click(object sender, EventArgs e)
        {
            int idEndereco = 0;
            if (Request["id"] != null)
            {
                idEndereco = Int32.Parse(Request["id"]);
            }
            int idUsuario = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
            Usuario usuario = new Usuario();
            usuario.IdUsuario = idUsuario;
            Endereco endereco = new Endereco(idEndereco, usuario, txtLocalEndereco.Text, Int32.Parse(txtNumeroEndereco.Text), txtBairroEndereco.Text, txtComplemento.Text, txtCepEndereco.Text);
            string resposta = "";

            if (Request["operacao"] != null)
            {
                string operacao = Request["operacao"].ToString();

                if (operacao == "A")
                {
                    resposta = new EnderecoDAO().alterarEndereco(endereco);
                }
                else if (operacao == "E")
                {
                    resposta = new EnderecoDAO().excluirEndereco(idEndereco);
                }
                else
                {
                    resposta = new EnderecoDAO().cadastrarEndereco(endereco);
                }
            }
            else
            {
                resposta = new EnderecoDAO().cadastrarEndereco(endereco);
            }

            if (resposta == "ok")
            {
                Response.Redirect("perfil_usuario.aspx");
            }
        }

        void preencherCampos()
        {
            Endereco endereco = new EnderecoDAO().buscarEnderecosUsuario(Int32.Parse(Request["id"]));

            if(endereco.NomeEndereco == "Sem retorno de endereços")
            {
                lblResposta.Text = endereco.NomeEndereco;
                lblResposta.Visible = true;
                btnSalvarEndereco.Enabled = false;
            }
            else
            {
                txtLocalEndereco.Text = endereco.NomeEndereco;
                txtBairroEndereco.Text = endereco.BairroEndereco;
                txtNumeroEndereco.Text = endereco.NumeroEndereco.ToString();
                txtCepEndereco.Text = endereco.CepEndereco;
                txtComplemento.Text = endereco.Complemento;
            }
        }
    }
}