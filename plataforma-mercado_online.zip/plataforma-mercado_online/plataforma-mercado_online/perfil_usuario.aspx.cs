﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class perfil_usuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["dadosUsuario"] != null)
            {
                int idUsuario = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
                titulo_nome_usuario.Text += Request.Cookies["dadosUsuario"].Values.Get("nomeUsuario");

                string sql = SqlDataSourceEnderecos.SelectCommand;
                sql +=  " WHERE [fk_Usuario_id_usu] = " + idUsuario + " AND ativo_enderec = 1 ";

                SqlDataSourceEnderecos.SelectCommand = sql;
                SqlDataSourceEnderecos.DataBind();
                gdvEnderecos.DataBind();
            }
            else
            {
                Server.Transfer("pagina_cadastro_usuario.aspx");
            }
            
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["dadosUsuario"].Expires = DateTime.Now.AddDays(-1);
            Server.Transfer("index.aspx");
        }
    }
}