﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Fornecedor
    {
        // Declaração das variáveis e seus métodos get set (via )
        public int IdFornecedor { get; set; }
        public string NomeForncedor { get; set; }
        public string Cnpj { get; set; }
        public string Endereco { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }

        // Declaração dos construtores
        public Fornecedor() { }

        public Fornecedor(int idDoFornecedor, string nomeDoForncedor, string cnpj, string endereco, string email, string telefone)
        {
            this.IdFornecedor = idDoFornecedor;
            this.NomeForncedor = nomeDoForncedor;
            this.Cnpj = cnpj;
            this.Endereco = endereco;
            this.Email = email;
            this.Telefone = telefone;
        }
    }
}