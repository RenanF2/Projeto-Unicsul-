﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Fornecedor
    {
        // Declaração das variáveis e seus métodos get set (via property)
        public int IdFornecedor { get; set; }
        public string NomeFornecedor { get; set; }
        public string CnpjFornecedor { get; set; }
        public string EnderecoFornecedor { get; set; }
        public string EmailFornecedor { get; set; }
        public string TelefoneFornecedor { get; set; }

        // Declaração dos construtores
        public Fornecedor() { }

        public Fornecedor(int idDoFornecedor, string nomeDoForncedor, string cnpjForncedor, string enderecoForncedor, string emailForncedor, string telefoneForncedor)
        {
            this.IdFornecedor = idDoFornecedor;
            this.NomeFornecedor = nomeDoForncedor;
            this.CnpjFornecedor = cnpjForncedor;
            this.EnderecoFornecedor = enderecoForncedor;
            this.EmailFornecedor = emailForncedor;
            this.TelefoneFornecedor = telefoneForncedor;
        }
    }
}