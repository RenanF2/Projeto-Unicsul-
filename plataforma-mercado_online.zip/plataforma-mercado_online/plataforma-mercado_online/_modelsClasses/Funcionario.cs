﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Funcionario
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdFuncionario { get; set; }
        public string NomeFuncionario { get; set; }
        public string CpfFuncionario { get; set; }
        public string SenhaFuncionario { get; set; }
        public string TelefoneFuncionario {get; set;}
        public string EmailFuncionario { get; set; }
        public double SalarioFuncionario { get; set; }
        public Cargo_Funcionario Cargo { get; set; }

        public Funcionario() { }

        public Funcionario(int idFuncionario, string nomeFuncionario, string cpfFuncionario, string senhaFuncionario, string telefoneFuncionario, string emailFuncionario, double salarioFuncionario, Cargo_Funcionario cargo)
        {
            this.IdFuncionario = idFuncionario;
            this.NomeFuncionario = nomeFuncionario;
            this.CpfFuncionario = cpfFuncionario;
            this.SenhaFuncionario = senhaFuncionario;
            this.TelefoneFuncionario = telefoneFuncionario;
            this.EmailFuncionario = emailFuncionario;
            this.SalarioFuncionario = salarioFuncionario;
            this.Cargo = cargo;
        }
    }
}