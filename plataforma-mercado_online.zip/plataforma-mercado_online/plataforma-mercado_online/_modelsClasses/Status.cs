﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Status
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdStatus { get; set; }
        public string NomeStatus { get; set; }
        public string DescricaoStatus { get; set; }

        // Declaração dos construtores
        public Status() { }

        public Status(int idStatus, string nomeStatus, string descricaoStatus)
        {
            this.IdStatus = idStatus;
            this.NomeStatus = nomeStatus;
            this.DescricaoStatus = descricaoStatus;
        }
    }
}