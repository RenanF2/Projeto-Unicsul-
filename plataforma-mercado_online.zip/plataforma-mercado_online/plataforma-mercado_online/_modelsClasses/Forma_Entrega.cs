﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Forma_Entrega
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdFormaEntrega { get; set; }
        public string NomeFormaEntrega { get; set; }
        public string DescricaoFormaEntrega { get; set; }

        // Declaração dos construtores
        public Forma_Entrega() { }

        public Forma_Entrega(int idFormaEntrega, string nomeFormaEntrega, string descricaoFormaEntrega)
        {
            this.IdFormaEntrega = idFormaEntrega;
            this.NomeFormaEntrega = nomeFormaEntrega;
            this.DescricaoFormaEntrega = descricaoFormaEntrega;
        }
    }
}