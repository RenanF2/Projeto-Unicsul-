﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Cargo_Funcionario
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdCargo { get; set; }
        public string NomeCargo { get; set; }
        public string DescricaoCargo { get; set; }

        // Declaração dos construtores
        public Cargo_Funcionario() { }

        public Cargo_Funcionario(int idCargo, string nomeCargo, string descricaoCargo)
        {
            this.IdCargo = idCargo;
            this.NomeCargo = nomeCargo;
            this.DescricaoCargo = descricaoCargo;
        }

    }
}