﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Cargo_Funcionario
    {
    }
}