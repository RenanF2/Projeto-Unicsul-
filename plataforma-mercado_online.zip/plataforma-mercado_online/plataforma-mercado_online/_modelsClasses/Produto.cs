﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Produto
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdProduto { get; set; }
        public int CodBarras { get; set; }
        public string NomeProduto { get; set; }
        public string DescricaoProduto { get; set; }
        public double PrecoUnitario { get; set; }
        // PrecoUnitarioConvertido - campo utilizado na necessidade de retorna o preço formatado 
        public string PrecoUnitarioConvertido { get; set; }
        public int QuantEstoque { get; set; }
        public int QuantMinimaEstoque { get; set; }
        public string ImgProduto { get; set; }
        public Categoria Categoria { get; set; }
        public Fornecedor Fornecedor { get; set; }
        //Atributos para formatação de preço e atributos de itens no carrinho
        public int QuantidadeItem { get; set; }
        public double SubTotalItem { get; set; }

        // Declaração dos construtores
        public Produto() { }

        public Produto(int idProduto, int codBarras, string nomeProduto, string descricaoProduto, double precoUnitario, int quantEstoque, int quantMinimaEstoque, string imgProduto, Categoria categoria, Fornecedor fornecedor)
        {
            this.IdProduto = idProduto;
            this.CodBarras = codBarras;
            this.NomeProduto = nomeProduto;
            this.DescricaoProduto = descricaoProduto;
            this.PrecoUnitario = precoUnitario;
            this.QuantEstoque = quantEstoque;
            this.QuantMinimaEstoque = quantMinimaEstoque;
            this.ImgProduto = imgProduto;
            this.Categoria = categoria;
            this.Fornecedor = fornecedor;
        }
    }
}