﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Usuario
    {

        // Declaração das variáveis e seus métodos get set (via property)
        public int IdUsuario { get; set; }
        public string NomeUsuario { get; set; }
        public string CpfUsuario { get; set; }
        public string EmailUsuario { get; set; }
        public string SenhaUsuario { get; set; }
        public DateTime DtNascimentoUsuario { get; set; }
        public string TelefoneUsuario { get; set; }

        // Declaração dos construtores
        public Usuario() { }

        public Usuario(int idUsuario, string nomeUsuario, string cpfUsuario, string emailUsuario, string senhaUsuario, DateTime dtNascimentoUsuario, string telefoneUsuario)
        {
            this.IdUsuario = idUsuario;
            this.NomeUsuario = nomeUsuario;
            this.CpfUsuario = cpfUsuario;
            this.EmailUsuario = emailUsuario;
            this.SenhaUsuario = senhaUsuario;
            this.DtNascimentoUsuario = dtNascimentoUsuario;
            this.TelefoneUsuario = telefoneUsuario;
        }


    }
}