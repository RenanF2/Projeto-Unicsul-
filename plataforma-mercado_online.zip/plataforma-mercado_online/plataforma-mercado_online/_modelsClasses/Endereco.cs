﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Endereco
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdEndereco { get; set; }
        public Usuario Cliente { get; set; }
        public string NomeEndereco { get; set; }
        public int NumeroEndereco { get; set; }
        public string BairroEndereco { get; set; }
        public string Complemento { get; set; }
        public string CepEndereco { get; set; }

        // Declaração dos construtores
        public Endereco() { }

        public Endereco(int idEndereco)
        {
            this.IdEndereco = idEndereco;
        }

        public Endereco(int idEndereco, Usuario cliente, string nomeEndereco, int numeroEndereco, string bairroEndereco, string complemento, string cepEndereco)
        {
            this.IdEndereco = idEndereco;
            this.Cliente = cliente;
            this.NomeEndereco = nomeEndereco;
            this.NumeroEndereco = numeroEndereco;
            this.BairroEndereco = bairroEndereco;
            this.Complemento = complemento;
            this.CepEndereco = cepEndereco;
        }

    }
}