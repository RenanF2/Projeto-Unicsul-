﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Pedido
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdPedido { get; set; }
        public Usuario Cliente { get; set; }
        public int IdFuncionario { get; set; }
        public List<Produto> Produtos { get; set; }
        public Endereco Endereco { get; set; }
        public double ValorTotal { get; set; }
        public string ValorTotalConvertido { get; set; }
        public int IdPagamento { get; set; }
        public int IdEntrega { get; set; }
        public int IdStatus { get; set; }

        // Declaração dos construtores
        public Pedido() { }

        public Pedido(Usuario cliente, int idStatus)
        {
            this.Cliente = cliente;
            this.IdStatus = idStatus;
        }

        public Pedido(int idPedido, Usuario cliente, int idFuncionario, List<Produto> produtos, Endereco endereco, double valorTotal, int idPagamento, int idEntrega, int idStatus)
        {
            this.IdPedido = idPedido;
            this.Cliente = cliente;
            this.IdFuncionario = idFuncionario;
            this.Produtos = produtos;
            this.Endereco = endereco;
            this.ValorTotal = valorTotal;
            this.IdPagamento = idPagamento;
            this.IdEntrega = idEntrega;
            this.IdStatus = idStatus;
        }
    }
}