﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class pagina_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["dadosUsuario"] != null)
            {
                Server.Transfer("index.aspx");
            }
            else
            {
                botao_login.Visible = true;
                btnLogout.Visible = false;
            }
        }

        protected void btnCadastrarUsuario_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario(0, txtNomeUsuario.Text, txtCpfUsuario.Text, txtEmailUsuario.Text, txtSenhaUsuario.Text, DateTime.Parse(txtNascimentoUsuario.Text), txtTelefoneUsuario.Text);
            string resposta;

            bool isExistente = new UsuarioDAO().verificarCPF(usuario.CpfUsuario);
            if(isExistente == false)
            {
                resposta = new UsuarioDAO().gravarUsuario(usuario);
            }
            else
            {
                resposta = "";
                lblResposta.Text = "Já existe um funcionário com este CPF";
                lblResposta.Visible = true;
                txtCpfUsuario.Focus();
            }

            //Ser houver uma resposta para o cadastro, retorna para a página inicial
            if (resposta == "ok")
            {
                Response.Redirect("index.aspx");
            }
        }

        //ignorar método
        protected void txtEmailUsuario_TextChanged(object sender, EventArgs e){}

        protected void btnLogar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new UsuarioDAO().fazerLoginUsuario(txtEmailLogin.Text, txtSenhaLogin.Text);

            if (usuario.IdUsuario != 0)
            {
                HttpCookie cookieUsuario = new HttpCookie("dadosUsuario");
                cookieUsuario["idUsuario"] = usuario.IdUsuario.ToString();
                cookieUsuario["nomeUsuario"] = usuario.NomeUsuario;
                cookieUsuario["cpfUsuario"] = usuario.CpfUsuario;

                cookieUsuario.Expires = DateTime.Now.AddDays(365);

                Response.Cookies.Add(cookieUsuario);

                Server.Transfer("perfil_usuario.aspx");
            }
            else
            {
                estiloDinamico.InnerText = "section.menu_suspenso { display: block; } #menu_navegacao{ display: none; }";
                lblResultado.Text = "Email e/ou senha incorreto(s)";
                lblResultado.Visible = true;
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["dadosUsuario"].Expires = DateTime.Now.AddDays(-1);
            botao_login.Visible = true;
            btnLogout.Visible = false;
        }
    }
}