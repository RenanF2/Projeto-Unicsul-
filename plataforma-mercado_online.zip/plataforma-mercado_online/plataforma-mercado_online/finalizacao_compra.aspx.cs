﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class finalizacao_compra : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["dadosUsuario"] != null)
            {
                if (!Page.IsPostBack)
                {
                    int idUsuario = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
                    SqlDataSourceEnderecos.SelectCommand = "SELECT id_enderec, nome_enderec, bairro_enderec, numero_enderec, cep_enderec, compl_enderec, fk_Usuario_id_usu FROM Endereco WHERE fk_Usuario_id_usu = " + idUsuario + " AND ativo_enderec = 1 ";
                    SqlDataSourceEnderecos.DataBind();
                    ddlEndereco.DataBind();

                    opcoesEntrega.Visible = false;
                    btnAplicarEntrega.Visible = false;
                    ddlEndereco.Visible = false;
                }
            }
            else
            {
                Server.Transfer("pagina_cadastro_usuario.aspx");
            }
        }

        protected void btnAplicarPagamento_Click(object sender, EventArgs e)
        {
            if (rdbCredito.Checked || rdbDebito.Checked || rdbBoleto.Checked || rdbPix.Checked)
            {
                int codigoPagamento = 0;
                int idUsuario = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
                Pedido pedidoCliente = new PedidoDAO().pesquisarPedidoAtivo(idUsuario);

                if (rdbCredito.Checked)
                {
                    codigoPagamento = 1;
                }
                if (rdbDebito.Checked)
                {
                    codigoPagamento = 2;
                }
                if (rdbBoleto.Checked)
                {
                    codigoPagamento = 3;
                }
                if (rdbPix.Checked)
                {
                    codigoPagamento = 4;
                }
                string resultado = new PedidoDAO().adicionarFormaPagamento(pedidoCliente.IdPedido, codigoPagamento);

                if (resultado == "Ok")
                {
                    opcoesPagamento.Visible = false;
                    btnAplicarPagamento.Visible = false;

                    opcoesEntrega.Visible = true;
                    btnAplicarEntrega.Visible = true;
                    ddlEndereco.Visible = true;

                    resultado = new PedidoDAO().atualizarStatusPedido(pedidoCliente.IdPedido, 3);
                }
            }
            else
            {
                lblResposta.Text = "Selecione uma das formas de pagamento";
                lblResposta.Visible = true;
            }
        }

        protected void btnAplicarEntrega_Click(object sender, EventArgs e)
        {
            if (rdbEntrega.Checked || rdbLocal.Checked)
            {
                int codigoEntrega;
                string resultado = "";
                int idUsuario = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
                Pedido pedidoCliente = new PedidoDAO().pesquisarPedidoAtivo(idUsuario);

                if (rdbEntrega.Checked)
                {
                    codigoEntrega = 1;
                    resultado = new PedidoDAO().adicionarEnderecoEntrega(pedidoCliente.IdPedido, Int32.Parse(ddlEndereco.SelectedValue));
                    resultado = new PedidoDAO().adicionarFormaEntrega(pedidoCliente.IdPedido, codigoEntrega);
                }
                if (rdbLocal.Checked)
                {
                    codigoEntrega = 2;
                    resultado = new PedidoDAO().adicionarFormaEntrega(pedidoCliente.IdPedido, codigoEntrega);
                }

                if (resultado == "Ok")
                {
                    resultado = new PedidoDAO().atualizarStatusPedido(pedidoCliente.IdPedido, 5);
                    Server.Transfer("perfil_usuario.aspx");
                }
            }
            else
            {
                opcoesEntrega.Visible = true;
                btnAplicarEntrega.Visible = true;
                ddlEndereco.Visible = true;

                lblResposta.Text = "Selecione uma das formas de entrega";
                lblResposta.Visible = true;
            }
        }

        protected void rdbEntrega_CheckedChanged(object sender, EventArgs e)
        {
            ddlEndereco.Visible = true;
        }

        //protected void txtEndereco_TextChanged(object sender, EventArgs e)
        //{
        //    if(!ddlEndereco.Text.Equals("") || ddlEndereco.Text != null)
        //    {
        //        btnAplicarEntrega.Enabled = true;
        //    }
        //}
    }
}