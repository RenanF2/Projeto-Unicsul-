﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class detalhes_produto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request["idProduto"] == null)
            {
                Server.Transfer("index.aspx");
            }
            else
            {
                Produto produto = new ProdutoDAO().pesquisarProduto(Int32.Parse(Request["idProduto"]));

                titulo_produto.Text = produto.NomeProduto;
                if(produto != null)
                {
                    imagem_item.InnerHtml = "<img src='_img/" + produto.ImgProduto + "'>";
                    descricao_item.InnerHtml = "<h3>" + produto.NomeProduto + "</h3><br><h4>Por <strong>" + produto.PrecoUnitarioConvertido.ToString() + "</strong></h4><br><h4><strong>Informações do produto:</strong></h4><p>" + produto.DescricaoProduto + "</p>";
                }
                else
                {
                    txtQuantidadeItem.Enabled = false;
                    btnAdicionarProduto.Enabled = false;
                }

                if (Request.Cookies["dadosUsuario"] != null)
                {
                    botao_login.Visible = false;
                    botao_cadastro.Visible = false;
                    btnLogout.Visible = true;
                    perfil.Visible = true;

                    int idCliente = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
                    Pedido pedido = new PedidoDAO().pesquisarPedidoAtivo(idCliente);
                    List<Produto> itens = new PedidoDAO().carregarItensPedido(pedido.IdPedido);

                    int[] status = {5, 6, 7, 8, 9};
                    if (status.Contains(pedido.IdStatus))
                    {
                        btnAdicionarProduto.Enabled = false;
                        btnAdicionarProduto.Text = "Pedido à espera de preaparação";
                    }

                    foreach (Produto item in itens)
                    {
                        if (item.IdProduto == produto.IdProduto)
                        {
                            btnAdicionarProduto.Enabled = false;
                            btnAdicionarProduto.Text = "Adicionado ao carrinho!";
                        }
                    }
                }
                else
                {
                    botao_login.Visible = true;
                    botao_cadastro.Visible = true;
                    btnLogout.Visible = false;
                    perfil.Visible = false;
                    btnAdicionarProduto.Enabled = false;
                }
            }
        }

        protected void inserirValores(object sender, EventArgs e)
        {
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["dadosUsuario"].Expires = DateTime.Now.AddDays(-1);
            botao_login.Visible = true;
            botao_cadastro.Visible = true;
            btnLogout.Visible = false;

            Server.Transfer("detalhes_produto.aspx");
        }

        protected void btnLogar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new UsuarioDAO().fazerLoginUsuario(txtEmailUsuario.Text, txtSenhaUsuario.Text);

            if (usuario.IdUsuario != 0)
            {
                HttpCookie cookieUsuario = new HttpCookie("dadosUsuario");
                cookieUsuario["idUsuario"] = usuario.IdUsuario.ToString();
                cookieUsuario["nomeUsuario"] = usuario.NomeUsuario;
                cookieUsuario["cpfUsuario"] = usuario.CpfUsuario;

                cookieUsuario.Expires = DateTime.Now.AddDays(365);

                Response.Cookies.Add(cookieUsuario);

                Server.Transfer("perfil_usuario.aspx");
            }
            else
            {
                est.InnerText = "section.menu_suspenso { display: block; } #menu_navegacao{ display: none; }";
                lblResultado.Text = "Email e/ou senha incorreto(s)";
                lblResultado.Visible = true;
            }
        }

        protected void btnAdicionarProduto_Click(object sender, EventArgs e)
        {
            int idCliente = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));

            if (idCliente != 0)
            {
                int idPedido;
                string resultado;

                Produto produto = new ProdutoDAO().pesquisarProduto(Int32.Parse(Request["idProduto"]));
                Pedido pedidoCliente = new PedidoDAO().pesquisarPedidoAtivo(idCliente);

                if (pedidoCliente.IdPedido == 0)
                {
                    Usuario cliente = new Usuario();
                    cliente.IdUsuario = idCliente;

                    Pedido pedidoNovo = new Pedido(cliente, 1);

                    idPedido = new PedidoDAO().criarPedido(pedidoNovo);
                }
                else
                {
                    idPedido = pedidoCliente.IdPedido;
                }
                resultado = new PedidoDAO().adicionarItem(idPedido, produto, Int32.Parse(txtQuantidadeItem.Text));

                if (resultado == "adicionado")
                {
                    btnAdicionarProduto.Enabled = false;
                    btnAdicionarProduto.Text = "Adicionado ao carrinho!";
                }
            }
        }
    }
}