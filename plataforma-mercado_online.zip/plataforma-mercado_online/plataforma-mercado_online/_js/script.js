
let botaoCadastro = document.querySelector("#botao_login");
let menuSuspenso = document.querySelector("#menu_suspenso");
let menuLogin = document.querySelector("#form_acesso");

let botaoQuantidade = document.getElementsByClassName("botao_quantidade");

botaoCadastro.addEventListener("click", function() {
    abrirMenuSuspenso();
});

menuLogin.addEventListener("click", function () {
    abrirMenuSuspenso();
});

menuSuspenso.addEventListener("click", function (e) {
    //Comando para verificar se o elemento clicado foi o com id em quest�o ou foi um elemento filho do mesmo
    e = window.event || e;
    //Se foi o elemento com o id em s� clicado, executa o c�digo dentro do if
    if (this === e.target) {
        $("#menu_suspenso").css("display", "none");
        $("#menu_navegacao").css("display", "block");
    }
});

function abrirMenuSuspenso() {
    $("#menu_suspenso").css("display", "block");
    $("#menu_navegacao").css("display", "none");
}

for (var i = 0; i < botaoQuantidade.length; i++) {
    botaoQuantidade[i].addEventListener("click", function () {
        abrirMenuSuspenso();
    });
}