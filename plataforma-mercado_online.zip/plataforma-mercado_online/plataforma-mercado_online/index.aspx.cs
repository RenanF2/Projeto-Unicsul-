﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["dadosUsuario"] != null)
            {
                botao_login.Visible = false;
                botao_cadastro.Visible = false;
                btnLogout.Visible = true;
                perfil.Visible = true;
            }
            else
            {
                botao_login.Visible = true;
                botao_cadastro.Visible = true;
                btnLogout.Visible = false;
                perfil.Visible = false;
            }

            string itens = "<h1>Destaques</h1>";
            List<Produto> produtos = new ProdutoDAO().listarProdutos();

            foreach(Produto produto in produtos){
                itens += "<div class='item col-xs-6 col-sm-4 col-md-4 col-lg-3'>";
                itens += "<article>";
                itens += "<a href='detalhes_produto.aspx?idProduto=" + produto.IdProduto.ToString() + "'><img src='_img/" + produto.ImgProduto + "'></a>";
                itens += "<div class='dados'><h4>" + produto.NomeProduto + "</h4><h4>" + produto.PrecoUnitarioConvertido.ToString() + "</h4></div>";
                itens += "</article></div>";
            }

            container_itens.InnerHtml = itens;
        }

        protected void btnLogar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new UsuarioDAO().fazerLoginUsuario(txtEmailUsuario.Text, txtSenhaUsuario.Text);

            if(usuario.IdUsuario != 0)
            {
                HttpCookie cookieUsuario = new HttpCookie("dadosUsuario");
                cookieUsuario["idUsuario"] = usuario.IdUsuario.ToString();
                cookieUsuario["nomeUsuario"] = usuario.NomeUsuario;
                cookieUsuario["cpfUsuario"] = usuario.CpfUsuario;

                cookieUsuario.Expires = DateTime.Now.AddDays(365);

                Response.Cookies.Add(cookieUsuario);

                Server.Transfer("perfil_usuario.aspx");
            }
            else
            {
                estiloDinamico.InnerText = "section.menu_suspenso { display: block; } #menu_navegacao{ display: none; }";
                lblResultado.Text = "Email e/ou senha incorreto(s)";
                lblResultado.Visible = true;
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["dadosUsuario"].Expires = DateTime.Now.AddDays(-1);
            botao_login.Visible = true;
            botao_cadastro.Visible = true;
            btnLogout.Visible = false;

            Server.Transfer("index.aspx");
        }
    }
}