﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online
{
    public partial class carrinho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int idCliente = 0;
            //idCliente = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
            if (Request.Cookies["dadosUsuario"] != null)
            {
                idCliente = Int32.Parse(Request.Cookies["dadosUsuario"].Values.Get("idUsuario"));
            }
            else
            {
                Server.Transfer("pagina_cadastro_usuario.aspx");
            }

            Pedido pedidoCliente = new PedidoDAO().pesquisarPedidoAtivo(idCliente);

            Session["IdPedido"] = pedidoCliente.IdPedido.ToString();

            if (pedidoCliente.IdPedido != 0)
            {
                List<Produto> itensPedido = new PedidoDAO().carregarItensPedido(pedidoCliente.IdPedido);
                

                tabela_carrinho.InnerHtml += "<table class='resultado-busca'>";
                tabela_carrinho.InnerHtml += "<tr><td>ID</td><td>Cod.De Barras</td><td>Produto</td><td>Quantidade</td><td>Sub-Total</td><td>Alterações</td><td>Retirar</td></tr>";

                foreach (Produto item in itensPedido)
                {
                    string itensCarrinho = "";
                    itensCarrinho += "<tr>";
                    itensCarrinho += "<td data-id='" + item.IdProduto + "'>" + item.IdProduto.ToString() + "</td>&#013";
                    itensCarrinho += "<td>" + item.CodBarras.ToString() + "</td>";
                    itensCarrinho += "<td>" + item.NomeProduto + "</td>";
                    itensCarrinho += "<td data-id='" + item.QuantidadeItem + "'>" + item.QuantidadeItem.ToString() + "</td>";
                    itensCarrinho += "<td>" + item.SubTotalItem.ToString() + "</td>";
                    itensCarrinho += "<td><p class='btn-danger botao_quantidade'>Mudar Quantidade</p></td>";
                    itensCarrinho += "<td><p class='btn btn-primary navbar-btn botao-excluir'>Excluir item</p></td>";
                    itensCarrinho += "</tr>";

                    tabela_carrinho.InnerHtml += itensCarrinho;
                }
                tabela_carrinho.InnerHtml += "<tr><td colspan='7'><strong>Valor Total:</strong> " + pedidoCliente.ValorTotalConvertido + " </td></tr>";
                tabela_carrinho.InnerHtml += "</table>";

                if (itensPedido == null)
                {
                    btnFinalizarCompra.Enabled = false;
                    lblInformacoesPedido.Visible = true;
                    lblInformacoesPedido.Text = "Não existe nenhum produto no carrinho";
                }
            }

            if (pedidoCliente.IdPedido == 0)
            {
                btnFinalizarCompra.Enabled = false;
                lblInformacoesPedido.Visible = true;
                lblInformacoesPedido.Text = "Não existe um pedido aberto ainda, adicione itens para abrir um";
            }

            if (pedidoCliente.IdStatus == 5 || pedidoCliente.IdStatus == 6 || pedidoCliente.IdStatus == 7 || pedidoCliente.IdStatus == 8 || pedidoCliente.IdStatus == 9)
            {
                btnFinalizarCompra.Enabled = false;
                btnFinalizarCompra.Text = "Pedido já fechado";
            }
        }

        protected void btnFinalizarCompra_Click(object sender, EventArgs e)
        {
            Server.Transfer("finalizacao_compra.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["dadosUsuario"].Expires = DateTime.Now.AddDays(-1);
            Server.Transfer("index.aspx");
        }

        protected void btnAlterarQuantidade_Click(object sender, EventArgs e)
        {
            string resposta = "";
            int idPedido = Int32.Parse(Session["IdPedido"].ToString());
            int idProduto = Int32.Parse(idProdutoAlterando.Value);

            List<Produto> itens = new PedidoDAO().carregarItensPedido(idPedido);

            foreach (Produto item in itens)
            {
                if (item.IdProduto == idProduto)
                {
                    resposta = new PedidoDAO().alterarItemPedido(idPedido, item, Int32.Parse(txtQuantidadeNova.Text));
                }
            }

            if(resposta == "Ok")
            {
                Server.Transfer("carrinho.aspx");
            }
        }

        protected void btnExcluirItem_Click(object sender, EventArgs e)
        {
            string resposta = "";
            int idPedido = Int32.Parse(Session["IdPedido"].ToString());
            int idProduto = Int32.Parse(idProdutoAlterando.Value);

            List<Produto> itens = new PedidoDAO().carregarItensPedido(idPedido);

            foreach (Produto item in itens)
            {
                if (item.IdProduto == idProduto)
                {
                    resposta = new PedidoDAO().excluirItemPedido(idPedido, item);
                }
            }

            if (resposta == "Ok")
            {
                Server.Transfer("carrinho.aspx");
            }
        }
    }
}