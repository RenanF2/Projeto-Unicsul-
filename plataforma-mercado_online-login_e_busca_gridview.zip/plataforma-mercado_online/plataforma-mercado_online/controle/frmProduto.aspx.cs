﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class frmProduto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
            //IsPostBack para pegar qualquer alteração feita nos campos e na página, mandando sempre os dados atualizados, principalmente no update
            if (!Page.IsPostBack) {
                if(Request["operacao"] != null)
                {
                    //recebe o dado da operação a ser realizada, vindo dos links de atualização ou exclusão de um produto do menu_produtos.aspx
                    string operacao = Request["operacao"].ToString();

                    //dependendo da operação, irá bloquear os campos q não podem ser alterados para determinada operação
                    if (operacao == "A")
                    {
                        txtIdProduto.Enabled = false;
                        txtCodigoBarrasProduto.Enabled = false;

                        btnFinalizarProduto.Text = "Alterar";
                        preencherCampos();
                    }

                    if (operacao == "E")
                    {
                        txtIdProduto.Enabled = false;
                        txtCodigoBarrasProduto.Enabled = false;
                        txtNomeProduto.Enabled = false;
                        txtPrecoProduto.Enabled = false;
                        txtQuantProduto.Enabled = false;
                        txtQuantMinProduto.Enabled = false;
                        txtDescricaoProduto.Enabled = false;
                        ddlCategoria.Enabled = false;
                        ddlFornecedor.Enabled = false;

                        btnFinalizarProduto.Text = "Excluir";
                        preencherCampos();
                    }
                }

                if (Request["id"] != null)
                {
                    txtIdProduto.Text = Request["id"].ToString();
                }
            }
        }

        protected void btnFinalizarProduto_Click(object sender, EventArgs e)
        {
            //passa os dados do formulário para os objetos instanciados no botão
            Fornecedor forn = new Fornecedor(Int32.Parse(ddlFornecedor.SelectedValue), ddlFornecedor.Text, null, null, null, null);
            Categoria categ = new Categoria(Int32.Parse(ddlCategoria.SelectedValue), ddlCategoria.Text, null);
            Produto prod = new Produto(Int32.Parse(txtIdProduto.Text), Int32.Parse(txtCodigoBarrasProduto.Text), txtNomeProduto.Text, txtDescricaoProduto.Text, Double.Parse(txtPrecoProduto.Text), Int32.Parse(txtQuantProduto.Text), Int32.Parse(txtQuantMinProduto.Text), categ, forn);

            string resposta;

            //executa uma ação a partir de uma determinada operação, se não for passado nenhum valor ou for um incorreto, o botão executa a ação de inserção por padrão
            if (Request["operacao"] != null)
            {
                string operacao = Request["operacao"].ToString();

                if (operacao == "A")
                {
                    resposta = new ProdutoDAO().alterarProduto(prod);
                }
                else if(operacao == "E")
                {
                    resposta = new ProdutoDAO().excluirProduto(Int32.Parse(txtIdProduto.Text));
                }
                else
                {
                    resposta = new ProdutoDAO().gravarProduto(prod);
                }
            }
            else
            {
                resposta = new ProdutoDAO().gravarProduto(prod);
            }

            //Ser houver uma resposta para operação, retorna para o menu de produtos
            if (resposta == "ok")
            {
                Response.Redirect("menu_produtos.aspx");
            }
        }

        void preencherCampos()
        {
            //método para preencher os campos com os dados do produto selecionado no GridView da página menu_produtos
            Produto prodSolicitado = new ProdutoDAO().pesquisarProduto(Int32.Parse(Request["id"]));

            if (prodSolicitado.NomeProduto.ToString() == "Não existe este produto no sistema.")
            {
                lblResposta.Text = prodSolicitado.NomeProduto.ToString();
                lblResposta.Visible = true;
                btnFinalizarProduto.Enabled = false;
            }
            else
            {
                txtCodigoBarrasProduto.Text = prodSolicitado.CodBarras.ToString();
                txtNomeProduto.Text = prodSolicitado.NomeProduto.ToString();
                txtDescricaoProduto.Text = prodSolicitado.DescricaoProduto.ToString();
                txtPrecoProduto.Text = prodSolicitado.PrecoUnitario.ToString();
                txtQuantProduto.Text = prodSolicitado.QuantEstoque.ToString();
                txtQuantMinProduto.Text = prodSolicitado.QuantMinimaEstoque.ToString();
                ddlCategoria.SelectedValue = prodSolicitado.Categoria.IdCategoria.ToString();
                ddlFornecedor.SelectedValue = prodSolicitado.Fornecedor.IdFornecedor.ToString();
            }
        }
    }
}