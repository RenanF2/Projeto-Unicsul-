﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_funcionarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
        }

        protected void btnBuscaFuncionario_Click(object sender, EventArgs e)
        {
            int num;
            string buscaCodigo = "";
            bool isNumero = Int32.TryParse(txtBuscaFuncionario.Text, out num);
            if (isNumero)
            {
                buscaCodigo = " OR id_func = '" + Int32.Parse(txtBuscaFuncionario.Text) + "';";
            }
            SqlDataSourceFuncionarios.SelectCommand = "SELECT id_func, nome_func, cpf_func, email_func, salario_func, tel_func, fk_Cargo_Funcionario_id_cargo , '<a href=frmFuncionario.aspx?id=' + CAST(id_func as VARCHAR(8)) + '&operacao=A>Alterar</a> | <a href=frmFuncionario.aspx?id=' + CAST(id_func as VARCHAR(8)) + '&operacao=E>Excluir</a>' AS link FROM Funcionario WHERE nome_func LIKE '%" + txtBuscaFuncionario.Text + "%' OR cpf_func = '" + txtBuscaFuncionario.Text + "' " + buscaCodigo;
            SqlDataSourceFuncionarios.DataBind();
            gdvFuncionarios.DataBind();

            if (gdvFuncionarios.Rows.Count <= 0)
            {
                lblResposta.Text = "Não houve retorno para '" + txtBuscaFuncionario.Text + "'";
                lblResposta.Visible = true;
            }
        }
    }
}