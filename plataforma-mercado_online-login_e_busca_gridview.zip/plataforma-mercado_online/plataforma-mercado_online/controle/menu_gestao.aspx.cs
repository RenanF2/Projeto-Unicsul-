﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_gestao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }

            if (Boolean.Parse(Session["logado"].ToString()) == true && Session["cargo"] != null)
            {
                txtTeste.Text = Session["cargo"].ToString();
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            //IGNORAR ESSE MÉTODO
            Session["logado"] = false;
            Server.Transfer("frmLogin.aspx");
        }

        protected void btnLogout_Click1(object sender, EventArgs e)
        {
            Session["logado"] = false;
            Session["cargo"] = null;
            Server.Transfer("frmLogin.aspx");
        }
    }
}