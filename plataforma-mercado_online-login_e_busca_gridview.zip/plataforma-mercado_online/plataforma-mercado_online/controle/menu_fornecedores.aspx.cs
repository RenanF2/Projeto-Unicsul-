﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_fornecedores : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
        }

        protected void btnBuscaFornecedor_Click(object sender, EventArgs e)
        {
            int num;
            string buscaCodigo = "";
            bool isNumero = Int32.TryParse(txtBuscaFornecedor.Text, out num);
            if (isNumero)
            {
                buscaCodigo = " OR id_fornec = '" + Int32.Parse(txtBuscaFornecedor.Text) + "'";
            }
            SqlDataSourceFornecedores.SelectCommand = "SELECT id_fornec, nome_fornec, cnpj_fornec, email_fornec, enderec_fornec, tel_fornec, '<a href=frmFornecedor.aspx?id=' + CAST(id_fornec as VARCHAR(8)) + '&operacao=A>Alterar</a> | <a href=frmFornecedor.aspx?id=' + CAST(id_fornec as VARCHAR(8)) + '&operacao=E>Excluir</a>' AS link FROM Fornecedor WHERE nome_fornec LIKE '%" + txtBuscaFornecedor.Text + "%' " + buscaCodigo;
            SqlDataSourceFornecedores.DataBind();
            gdvFornecedores.DataBind();

            if (gdvFornecedores.Rows.Count <= 0)
            {
                lblResposta.Text = "Não houve retorno para '" + txtBuscaFornecedor.Text + "'";
                lblResposta.Visible = true;
            }
        }
    }
}