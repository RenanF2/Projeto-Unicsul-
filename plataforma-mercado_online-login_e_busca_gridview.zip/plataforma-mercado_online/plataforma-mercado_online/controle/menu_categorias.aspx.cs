﻿using plataforma_mercado_online._DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_categorias : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnBuscaCategoria_Click(object sender, EventArgs e)
        {
            int num;
            string buscaCodigo = "";
            bool isNumero = Int32.TryParse(txtBuscaCategoria.Text, out num);
            if (isNumero)
            {
                buscaCodigo = " OR id_categoria = '" + Int32.Parse(txtBuscaCategoria.Text) + "'";
            }
            SqlDataSourceCategorias.SelectCommand = "SELECT id_categoria, nome_categoria, descr_categoria , '<a href=frmCategoria.aspx?id=' + CAST(id_categoria as VARCHAR(8)) + '&operacao=A>Alterar</a> | <a href=frmCategoria.aspx?id=' + CAST(id_categoria as VARCHAR(8)) + '&operacao=E>Excluir</a>' as links FROM Categoria WHERE nome_categoria LIKE '%" + txtBuscaCategoria.Text + "%' " + buscaCodigo;
            SqlDataSourceCategorias.DataBind();
            gdvCategorias.DataBind();

            if(gdvCategorias.Rows.Count <= 0)
            {
                lblResposta.Text = "Não houve retorno para '" + txtBuscaCategoria.Text + "'";
                lblResposta.Visible = true;
            }
        }
    }
}