﻿using plataforma_mercado_online._DAO;
using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class frmCategoria : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
            //IsPostBack para pegar qualquer alteração feita nos campos e na página, mandando sempre os dados atualizados, principalmente no update
            if (!Page.IsPostBack)
            {
                if (Request["operacao"] != null)
                {
                    //recebe o dado da operação a ser realizada, vindo dos links de atualização ou exclusão de uma categoria do menu_categorias.aspx
                    string operacao = Request["operacao"].ToString();

                    //dependendo da operação, irá bloquear os campos q não podem ser alterados para determinada operação
                    if (operacao == "A")
                    {
                        txtIdCategoria.Enabled = false;

                        btnFinalizarCategoria.Text = "Alterar";
                        preencherCamposCategoria();
                    }

                    if (operacao == "E")
                    {
                        txtIdCategoria.Enabled = false;
                        txtNomeCategoria.Enabled = false;
                        txtDescricaoCategoria.Enabled = false;

                        btnFinalizarCategoria.Text = "Excluir";
                        preencherCamposCategoria();
                    }
                }

                if (Request["id"] != null)
                {
                    txtIdCategoria.Text = Request["id"].ToString();
                }
            }
        }

        protected void btnFinalizarCategoria_Click(object sender, EventArgs e)
        {
            Categoria cat = new Categoria(Int32.Parse(txtIdCategoria.Text), txtNomeCategoria.Text, txtDescricaoCategoria.Text);
            string resposta;

            if (Request["operacao"] != null)
            {
                string operacao = Request["operacao"].ToString();
                if (operacao == "A")
                {
                    resposta = new CategoriaDAO().alterarCategoria(cat);
                }
                else if (operacao == "E")
                {
                    bool isDependencias = new CategoriaDAO().verificarDependenciasCategoria(cat.IdCategoria);
                    if (isDependencias == false)
                    {
                        resposta = new CategoriaDAO().excluirCategoria(cat.IdCategoria);
                    }
                    else
                    {
                        resposta = "";
                    }
                }
                else
                {
                    resposta = new CategoriaDAO().gravarCategoria(cat);
                }
            }
            else
            {
                resposta = new CategoriaDAO().gravarCategoria(cat);
            }

            if (resposta == "ok")
            {
                Response.Redirect("menu_categorias.aspx");
            }
        }

        void preencherCamposCategoria()
        {
            //método para preencher os campos com os dados do produto selecionado no GridView da página menu_produtos
            Categoria catSolicitado = new CategoriaDAO().pesquisarCategoria(Int32.Parse(Request["id"]));

            if (catSolicitado.NomeCategoria.ToString() == "Não existe esta categoria no sistema.") 
            {
                lblResposta.Text = catSolicitado.NomeCategoria.ToString();
                lblResposta.Visible = true;
                btnFinalizarCategoria.Enabled = false;
            }
            else
            {
                txtNomeCategoria.Text = catSolicitado.NomeCategoria.ToString();
                txtDescricaoCategoria.Text = catSolicitado.DescricaoCategoria.ToString();
            }
        }
    }
}