﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class menu_produtos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null || Boolean.Parse(Session["logado"].ToString()) == false || Session["cargo"] == null)
            {
                Server.Transfer("frmLogin.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnBuscaProduto_Click(object sender, EventArgs e)
        {
            int num;
            string buscaCodigo = "";
            bool isNumero = Int32.TryParse(txtBuscaProduto.Text, out num);
            if (isNumero)
            {
                buscaCodigo = " OR id_produto = '" + Int32.Parse(txtBuscaProduto.Text) + "' OR cod_barras_produto = '" + Int32.Parse(txtBuscaProduto.Text) + "';";
            }
            SqlDataSourceProdutos.SelectCommand = "SELECT id_produto, nome_produto, precUnit_produto, quant_produto, fk_Categoria_id_categoria, '<a href=frmProduto.aspx?id=' + CAST(id_produto as VARCHAR(8)) + '&operacao=A>Alterar</a> | <a href=frmProduto.aspx?id=' + CAST(id_produto as VARCHAR(8)) + '&operacao=E>Excluir</a>' AS link FROM Produto WHERE nome_produto LIKE '%" + txtBuscaProduto.Text + "%' " + buscaCodigo;
            SqlDataSourceProdutos.DataBind();
            gdvProdutos.DataBind();

            if (gdvProdutos.Rows.Count <= 0)
            {
                lblResposta.Text = "Não houve retorno para '" + txtBuscaProduto.Text + "'";
                lblResposta.Visible = true;
            }
        }
    }
}