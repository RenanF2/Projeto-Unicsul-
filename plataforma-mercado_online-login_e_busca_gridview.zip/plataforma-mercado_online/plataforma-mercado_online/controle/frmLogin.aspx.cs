﻿using plataforma_mercado_online._DAO;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plataforma_mercado_online.controle
{
    public partial class frmLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["logado"] == null)
            {
                Session["logado"] = false;
            }

            if (Boolean.Parse(Session["logado"].ToString()) == true || Session["cargo"] != null)
            {
                Server.Transfer("menu_gestao.aspx");
            }
        }

        protected void btnLogar_Click(object sender, EventArgs e)
        {
            int acesso = new FuncionarioDAO().fazerLoginFuncionario(txtCPF.Text, txtSenha.Text);
            if (acesso != 0)
            {
                Session["logado"] = true;
                Session["cargo"] = acesso.ToString();
                Server.Transfer("menu_gestao.aspx");
            }
        }
    }
}