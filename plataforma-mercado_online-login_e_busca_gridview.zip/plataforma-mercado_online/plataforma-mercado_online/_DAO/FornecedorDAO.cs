﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class FornecedorDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public FornecedorDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string gravarFornecedor(Fornecedor fornecedor)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "INSERT INTO Fornecedor (id_fornec, nome_fornec, cnpj_fornec, email_fornec, enderec_fornec, tel_fornec) ";
                sql += " VALUES (" + fornecedor.IdFornecedor + ", '" + fornecedor.NomeFornecedor + "', '" + fornecedor.CnpjFornecedor + "', '" + fornecedor.EmailFornecedor + "', '" + fornecedor.EnderecoFornecedor + "', '" + fornecedor.TelefoneFornecedor + "')";
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na inserção - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string alterarFornecedor(Fornecedor fornecedor)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "UPDATE Fornecedor SET nome_fornec = '" + fornecedor.NomeFornecedor + "', cnpj_fornec = '" + fornecedor.CnpjFornecedor + "', email_fornec = '" + fornecedor.EmailFornecedor +"', enderec_fornec = '" + fornecedor.EnderecoFornecedor + "', tel_fornec = '" + fornecedor.TelefoneFornecedor + "' ";
                sql += "WHERE id_fornec = " + fornecedor.IdFornecedor;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na alteração - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }

        public string excluirFornecedor(int id)
        {
            string resp;
            string sql = "";
            int retorno;

            try
            {
                sql = "DELETE FROM Fornecedor WHERE id_fornec = " + id;
                cmd = new SqlCommand(sql, conexao);
                retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    return "ok";
                }
                else
                {
                    return "Erro na exclusão - Comando: " + sql;
                }
            }
            catch (Exception erro)
            {
                resp = "ERRO: " + erro.ToString() + " SQL: " + sql;
            }
            return resp;
        }
    
        public Fornecedor pesquisarFornecedor(int id)
        {
            Fornecedor forn = new Fornecedor();
            string sql;

            try
            {
                sql = "SELECT id_fornec, nome_fornec, cnpj_fornec, email_fornec, enderec_fornec, tel_fornec FROM Fornecedor WHERE id_fornec = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    forn.IdFornecedor = Int32.Parse(dr["id_fornec"].ToString());
                    forn.NomeFornecedor = dr["nome_fornec"].ToString();
                    forn.CnpjFornecedor = dr["cnpj_fornec"].ToString();
                    forn.EmailFornecedor = dr["email_fornec"].ToString();
                    forn.EnderecoFornecedor = dr["enderec_fornec"].ToString();
                    forn.TelefoneFornecedor = dr["tel_fornec"].ToString();
                    return forn;
                }
                else
                {
                    forn.NomeFornecedor = "Não existe este fornecedor no sistema.";
                    return forn;
                }
            }
            catch(Exception erro)
            {
                forn.NomeFornecedor = "ERRO: " + erro.ToString();
                return forn;
            }
        }

        public bool verificarDependenciasFornecedor(int id)
        {
            string sql;
            try
            {
                sql = "SELECT id_produto FROM Produto p INNER JOIN Fornecedor f ON (f.id_fornec = p.fk_Fornecedor_id_fornec) WHERE f.id_fornec = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception erro)
            {
                return false;
            }

        }
    }
}