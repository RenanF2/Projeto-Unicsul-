﻿using plataforma_mercado_online._modelsClasses;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._DAO
{
    public class StatusDAO
    {
        SqlConnection conexao = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Comercio.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        public StatusDAO()
        {
            try
            {
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Status pesquisarStatus(int id)
        {
            Status status = new Status();
            string sql;

            try
            {
                sql = "SELECT id_status, nome_status, descr_status FROM Status WHERE id_status = " + id;
                cmd = new SqlCommand(sql, conexao);
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    status.IdDoPedido = Int32.Parse(dr["id_status"].ToString());
                    status.NomeStatus = dr["nome_status"].ToString();
                    status.DescricaoStatus = dr["descr_status"].ToString();
                    return status;
                }
                else
                {
                    status.NomeStatus = "Não existe este status no sistema.";
                    return status;
                }
            }
            catch (Exception erro)
            {
                status.NomeStatus = "ERRO: " + erro.ToString();
                return status;
            }
        }
    }
}