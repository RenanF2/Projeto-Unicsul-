﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Categoria
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdCategoria { get; set; }
        public string NomeCategoria { get; set; }
        public string DescricaoCategoria { get; set; }

        // Declaração dos construtores
        public Categoria() { }

        public Categoria(int idCategoria, string nomeCategoria, string descricaoCategoria)
        {
            this.IdCategoria = idCategoria;
            this.NomeCategoria = nomeCategoria;
            this.DescricaoCategoria = descricaoCategoria;
        }
    }
}