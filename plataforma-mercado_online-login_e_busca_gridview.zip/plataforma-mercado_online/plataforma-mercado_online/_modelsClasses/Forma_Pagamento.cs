﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace plataforma_mercado_online._modelsClasses
{
    public class Forma_Pagamento
    {
        // Declaração das variáveis e seus métodos get e set (via Property)
        public int IdMetodoPag { get; set; }
        public string NomeMetodoPag { get; set; }
        public string DescricaoMetodoPag { get; set; }

        // Declaração dos construtores
        public Forma_Pagamento() { }

        public Forma_Pagamento(int idMetodoPag, string nomeMetodoPag, string descricaoMetodoPag)
        {
            this.IdMetodoPag = idMetodoPag;
            this.NomeMetodoPag = nomeMetodoPag;
            this.DescricaoMetodoPag = descricaoMetodoPag;
        }
    
    }
}